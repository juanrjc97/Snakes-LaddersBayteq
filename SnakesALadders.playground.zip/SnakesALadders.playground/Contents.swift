import UIKit

var playerSquare =  0
var dice = 0
var LastSquare = 100
var board : [Int] = Array(repeating: 0, count: LastSquare + 1)

//adding steps for ladder
board[2]  = +36 ;  board[7]  = +7  ; board[8]  = +23 ; board[15] = +11
board[21] = +21 ;  board[28] = +56 ; board[36] = +8  ; board[51] = +16
board[71] = +10 ;  board[78] = +20 ; board[87] = +7
//remove positions for snakes
board[16] = -10 ;  board[46] = -21 ; board[49] = -38  ; board[62] = -43
board[64] = -4  ;  board[74] = -21 ; board[89] = -21  ; board[92] = -4
board[95] = -20 ;  board[99] = -19

print("Inicio del Juego en el cuadro #1")

while playerSquare < LastSquare {
    
    //roll the dice
    dice = diceRoll()
    var previousSquare = playerSquare
    var newPossition = previousSquare + dice
    //player still on the game
    if newPossition < board.count {
            playerSquare = newPossition
            var upDown = ""
        if board[playerSquare] > 0 {
            upDown = "You Got Ladders"
        }else if board[playerSquare] < 0{
            upDown = "You Got Snakes"
        }
            playerSquare += board[playerSquare]
            print("Resultado del Dado : \(dice)  \n \(upDown) \nNueva Posicion: \(playerSquare)\n")
    }
   
}
print("GANASTE")

func diceRoll() -> Int {
    return  Int.random(in: 1..<6)
}
