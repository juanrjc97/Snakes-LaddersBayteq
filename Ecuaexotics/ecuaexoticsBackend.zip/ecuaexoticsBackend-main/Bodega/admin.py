from django.contrib import admin
from .models import Bodega

myModels = [Bodega]
admin.site.register(myModels)
