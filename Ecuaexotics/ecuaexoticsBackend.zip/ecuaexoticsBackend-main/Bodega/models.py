from django.db import models
from datetime import datetime
from Productor.models import Productor
from Usuario.models import Usuario


class Bodega(models.Model):
    bodega = "Bodega"
    calibrado = "Calibrado"
    finalizado = "Finalizado"

    estados = [
        (bodega, "Bodega"),
        (calibrado, "Calibrado"),
        (finalizado, "Finalizado"),
    ]

    yellow = "Yellow Dragon Fruit"
    red = "Red Dragon Fruit"

    tipos_pitahaya = [
        (yellow, "Yellow Dragon Fruit"),
        (red, "Red Dragon Fruit"),
    ]

    id_bodega = models.AutoField(primary_key=True, unique=True)
    fecha = models.DateTimeField(
        default=datetime.now, verbose_name="Fecha")
    num_gavetas = models.IntegerField(verbose_name="Nº gavetas")
    estado = models.CharField(
        choices=estados, default=bodega, max_length=25, verbose_name="Estado")
    tipo_pitahaya = models.CharField(
        choices=tipos_pitahaya, default=red, max_length=50, verbose_name="Tipo pitahaya")
    id_productor = models.ForeignKey(
        Productor, on_delete=models.PROTECT, verbose_name="Productor")
    id_usuario = models.ForeignKey(
        Usuario, on_delete=models.PROTECT, verbose_name="Usuario")

    class Meta:
        verbose_name = "Bodega"
        verbose_name_plural = "Bodegas"

    def __str__(self):
        return '{} {} {}'.format(self.num_gavetas, self.id_productor.nombre, self.id_productor.apellido)
