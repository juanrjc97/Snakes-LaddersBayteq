from .models import Bodega
from rest_framework import serializers
from Productor.serializers import ProductorSerializer
from Usuario.serializers import UsuarioSerializer


class BodegaSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = Bodega
        fields = '__all__'


class BodegaUpdateSerializer(serializers.ModelSerializer):

    class Meta:
        model = Bodega
        fields = [
            'num_gavetas'
        ]


class BodegaSerializer(serializers.ModelSerializer):
    id_productor = ProductorSerializer()
    id_usuario = UsuarioSerializer()

    class Meta:
        model = Bodega
        fields = '__all__'
