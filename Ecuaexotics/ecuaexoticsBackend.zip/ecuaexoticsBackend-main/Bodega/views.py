from .models import Bodega
from django.conf import settings
from django.db.models import Q

from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from .serializers import BodegaSerializer, BodegaSimpleSerializer, BodegaUpdateSerializer

from ConfigEmail.BuildBodyEmail import _bodyInitProcessBodega
from ConfigEmail.EmailBackend import EmailBackend

from rest_framework.generics import GenericAPIView


class GetListBodega(APIView):
    """
        Permite obtener una lista de bitacoras de gavetas recibidas
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna un json con de todas las bitacoras con estado de bodega.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        bodegaObject = Bodega.objects.all().order_by(
            '-fecha').filter(Q(estado="Bodega"))
        bodegaSerializer = BodegaSerializer(
            bodegaObject, many=True)
        return Response(bodegaSerializer.data, status=status.HTTP_200_OK)


class GetListBodegaAndCalibrado(APIView):
    """
        Permite obtener una lista de bitacoras con todos los estados de Bodega, calibrado y finalizado
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna un json con de todas las bitacoras.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        bodegaObject = Bodega.objects.all().order_by('-fecha', 'estado')
        bodegaSerializer = BodegaSerializer(
            bodegaObject, many=True)
        return Response(bodegaSerializer.data, status=status.HTTP_200_OK)


class SaveBodega(APIView):
    """
        Permite guardar en la base de datos un bitacora
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de bitacora guardada y el id del registro.
                         http 400 => Retorna mensaje de error al guardar bitacora.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:

            bodegaSerializer = BodegaSimpleSerializer(data=request.data)

            if bodegaSerializer.is_valid():
                bodega = bodegaSerializer.save()
                productor = bodega.id_productor
                body = _bodyInitProcessBodega(productor, bodega)
                asunt = 'Notificaciones Ecuaexotics'

                messsageEmail(asunt, body, productor.email)

                return Response(
                    {
                        "message": "Se ha guardado bitácora correctamente",
                        "bodegaId": bodega.id_bodega
                    },
                    status=status.HTTP_201_CREATED,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido crear la bitácora"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class ActualizarBodega(APIView):
    """
        Permite actualizar datos de una bitacora previamente guardada
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de bitacora actualizada y el id del registro.
                         http 400 => Retorna mensaje de error al actualizar bitacora.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]
    def put(self, request, id_bodega, format=None):
        try:
            bodega = Bodega.objects.get(id_bodega=id_bodega)
            bodegaSerializer = BodegaUpdateSerializer(
                bodega, data=request.data)

            if bodegaSerializer.is_valid():
                bodega = bodegaSerializer.save()

                return Response(
                    {
                        "message": "Se ha actualizado bitácora correctamente",
                        "bodegaId": bodega.id_bodega
                    },
                    status=status.HTTP_202_ACCEPTED,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido crear la bitácora"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class GetListBodegaByIdProductor(APIView):
    """
        Permite obtener lista de bitacoras que perpetenecen a un productor
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de bitacora guardada y el id del registro.
                         http 400 => Retorna mensaje de error al guardar bitacora.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_productor, format=None):
        bodegaObject = Bodega.objects.filter(
            Q(id_productor=id_productor)).order_by('-fecha')
        bodegaSerializer = BodegaSerializer(
            bodegaObject, many=True)
        return Response(bodegaSerializer.data, status=status.HTTP_200_OK)


def messsageEmail(asunt, body, emailDst):
    try:
        # listToMail se agregan las direcciones de correos que desean que lleguen las notificaciones por correo
        listToEmail = []
        email_from = 'Ecuaexotics' + ' <settings.EMAIL_HOST_USER>'
        listToEmail += [emailDst]
        contentEmail = EmailBackend(
            asunt, body, email_from,  listToEmail)
        contentEmail.sendNormalMsg()
    except:
        pass
