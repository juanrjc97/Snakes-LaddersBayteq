from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path("crear_bitacora/", SaveBodega.as_view()),
    path("obtener_bitacoras/", GetListBodega.as_view()),
    path("obtener_todas_bitacoras/", GetListBodegaAndCalibrado.as_view()),
    path("obtener_bitacoras_by_productor/<str:id_productor>/",
         GetListBodegaByIdProductor.as_view()),
    path("actualizar_bitacora/<str:id_bodega>/", ActualizarBodega.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
