from django.contrib import admin
from .models import Palletizado, Pallet, ItemPallet

myModels = [Palletizado, Pallet, ItemPallet]
admin.site.register(myModels)
