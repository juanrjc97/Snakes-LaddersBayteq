from .models import Palletizado, Pallet, ItemPallet
from rest_framework import serializers
from Productor.serializers import ProductorSerializer
# from Cliente.serializers import ClienteSerializer


class PalletizadoSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = Palletizado
        fields = '__all__'


class PalletSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = Pallet
        fields = '__all__'

# class PalletFullSerializer(serializers.ModelSerializer):

#     id_cliente = ClienteSerializer()

#     class Meta:
#         model = Pallet
#         fields = '__all__'


class ItemPalletSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = ItemPallet
        fields = '__all__'


class ItemPalletFullSerializer(serializers.ModelSerializer):
    id_productor = ProductorSerializer()

    class Meta:
        model = ItemPallet
        fields = '__all__'
