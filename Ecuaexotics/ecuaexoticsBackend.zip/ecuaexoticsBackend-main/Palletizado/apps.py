from django.apps import AppConfig


class PalletizadoConfig(AppConfig):
    name = 'Palletizado'
