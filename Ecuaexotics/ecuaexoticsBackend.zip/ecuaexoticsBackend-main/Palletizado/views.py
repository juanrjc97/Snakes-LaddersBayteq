from .models import Palletizado, Pallet, ItemPallet
from Documentos.models import PackingList, Factura
from Calibrado.models import Caja
from .serializers import (
    PalletizadoSimpleSerializer,
    PalletSimpleSerializer,
    ItemPalletSimpleSerializer,
    ItemPalletFullSerializer
)
from Documentos.serializers import PackingListSimpleSerializer, FacturaSimpleSerializer
from Bodega.models import Bodega
from Cliente.models import Cliente
from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView


class SavePalletizado(APIView):
    """
        Permite crear la instancia de palletizado
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna id del palletizado creado
                         http 400 => Retorna mensaje de error al no poder crear palletizado
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            palletizadoSerializer = PalletizadoSimpleSerializer(
                data=request.data)

            if palletizadoSerializer.is_valid():
                palletizado = palletizadoSerializer.save()
                return Response(
                    {
                        "id_palletizado": palletizado.id_palletizado,
                    },
                    status=status.HTTP_201_CREATED,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido crear registro palletizado"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class GetPalletizado(APIView):
    """
        Permite obtener toda la información asociada al ultimo palletizado
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna información del palletizado
                         http 400 => Retorna mensaje de palletizado no disponible
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        try:
            palletizadoList = Palletizado.objects.all().order_by('-id_palletizado')
            if len(palletizadoList) > 0:
                palletizado = palletizadoList[0]
                palletizado_object = {
                    "id_palletizado": palletizado.id_palletizado,
                    "fecha": palletizado.fecha,
                    "pallets": []
                }
                list_pallet = Pallet.objects.filter(
                    Q(id_palletizado=palletizado.id_palletizado))

                for pallet in list_pallet:
                    cliente_object = {
                        "id_cliente": pallet.id_cliente.id_cliente,
                        "nombre": pallet.id_cliente.nombre,
                        "direccion": pallet.id_cliente.direccion,
                        "destino_orden": pallet.id_cliente.destino_orden,
                        "notify_address": pallet.id_cliente.notify_address,
                        "notify": pallet.id_cliente.notify
                    }

                    pallet_object = {
                        "id_pallet": pallet.id_pallet,
                        "tipo_pitahaya": pallet.tipo_pitahaya,
                        "fecha": pallet.fecha,
                        "cliente": cliente_object,
                        "total_cajas": 0,
                        "items": []
                    }

                    items_pallet = ItemPallet.objects.filter(
                        Q(id_pallet=pallet.id_pallet))

                    contCajasPallet = 0
                    for item in items_pallet:
                        poductor_object = {
                            "id_productor": item.id_productor.id_productor,
                            "nombre": item.id_productor.nombre,
                            "apellido": item.id_productor.apellido,
                            "email": item.id_productor.email,
                            "direccion": item.id_productor.direccion,
                            "telefono": item.id_productor.telefono
                        }
                        item_object = {
                            "id_item_pallet": item.id_item_pallet,
                            "tipo_caja": item.tipo_caja,
                            "num_cajas": item.num_cajas,
                            "calibre": item.calibre,
                            "id_pallet": item.id_pallet.id_pallet,
                            "productor": poductor_object
                            # "id_usuario": item.id_usuario.id,
                            # "id_caja": item.id_caja.id_caja
                        }
                        contCajasPallet += item.num_cajas
                        pallet_object["items"].append(item_object)

                    pallet_object["total_cajas"] = contCajasPallet
                    palletizado_object["pallets"].append(pallet_object)
                return Response(
                    palletizado_object,
                    status=status.HTTP_200_OK
                )
            else:
                return Response(
                    [],
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"message": "No existe el pallet solicitado"},
                status=status.HTTP_400_BAD_REQUEST
            )


class UpdateClienteInPallet(APIView):
    """
        Permite cambiar el cliente en un pallet
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de cliente actualizado en pallet
                         http 400 => Retorna mensaje de error al actualziar cliente
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_pallet, format=None):
        try:
            pallet = Pallet.objects.get(id_pallet=id_pallet)
            if pallet:
                if pallet.id_cliente.id_cliente != request.data['id_cliente']:
                    cliente = Cliente.objects.get(
                        id_cliente=request.data['id_cliente'])

                    palletList = Pallet.objects.filter(
                        Q(id_cliente=pallet.id_cliente.id_cliente) &
                        Q(id_palletizado=pallet.id_palletizado.id_palletizado))

                    if len(palletList) > 1:
                        dataDoc = {
                            'id_cliente':     cliente.id_cliente,
                            'id_palletizado': pallet.id_palletizado.id_palletizado
                        }
                        serializerPacking = PackingListSimpleSerializer(
                            data=dataDoc)
                        if serializerPacking.is_valid():
                            serializerPacking.save()

                        serializerFactura = FacturaSimpleSerializer(
                            data=dataDoc)
                        if serializerFactura.is_valid():
                            serializerFactura.save()
                    else:
                        packingList = PackingList.objects.filter(
                            Q(id_cliente=request.data['id_cliente']) & Q(id_palletizado=pallet.id_palletizado.id_palletizado))

                        facturaList = Factura.objects.filter(
                            Q(id_cliente=request.data['id_cliente']) & Q(id_palletizado=pallet.id_palletizado.id_palletizado))

                        if len(packingList) < 1 and len(facturaList) < 1:

                            packingObject = PackingList.objects.get(
                                id_cliente=pallet.id_cliente.id_cliente,
                                id_palletizado=pallet.id_palletizado.id_palletizado)
                            packingObject.id_cliente = cliente
                            packingObject.save()

                            facturaObject = Factura.objects.get(
                                id_cliente=pallet.id_cliente.id_cliente,
                                id_palletizado=pallet.id_palletizado.id_palletizado)
                            facturaObject.id_cliente = cliente
                            facturaObject.save()
                        else:
                            packingObject = PackingList.objects.get(
                                id_cliente=pallet.id_cliente.id_cliente,
                                id_palletizado=pallet.id_palletizado.id_palletizado)
                            packingObject.delete()

                            facturaObject = Factura.objects.get(
                                id_cliente=pallet.id_cliente.id_cliente,
                                id_palletizado=pallet.id_palletizado.id_palletizado)
                            facturaObject.delete()

                    pallet.id_cliente = cliente
                    pallet.save()
            return Response(
                {"message": "Se ha actualizado el cliente en el pallet"},
                status=status.HTTP_200_OK
            )
        except:
            return Response(
                {"message": "No existe el pallet solicitado"},
                status=status.HTTP_400_BAD_REQUEST
            )


class SavePallet(APIView):
    """
        Permite guardar registro de pallet
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna el id del nuevo objecto pallet
                         http 400 => Retorna mensaje de error al no poder crear pallet
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            palletSerializer = PalletSimpleSerializer(
                data=request.data)

            if palletSerializer.is_valid():
                pallet = palletSerializer.save()
                packingList = PackingList.objects.filter(
                    Q(id_cliente=pallet.id_cliente.id_cliente) & Q(id_palletizado=pallet.id_palletizado.id_palletizado))
                facturaList = Factura.objects.filter(
                    Q(id_cliente=pallet.id_cliente.id_cliente) & Q(id_palletizado=pallet.id_palletizado.id_palletizado))
                if len(packingList) == 0 and len(facturaList) == 0:
                    dataDoc = {
                        'id_cliente':     pallet.id_cliente.id_cliente,
                        'id_palletizado': pallet.id_palletizado.id_palletizado
                    }
                    serializerPacking = PackingListSimpleSerializer(
                        data=dataDoc)
                    if serializerPacking.is_valid():
                        serializerPacking.save()

                    serializerFactura = FacturaSimpleSerializer(data=dataDoc)
                    if serializerFactura.is_valid():
                        serializerFactura.save()

                return Response(
                    {
                        "id_pallet": pallet.id_pallet,
                    },
                    status=status.HTTP_201_CREATED,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido crear registro pallet"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class SaveItemPallet(APIView):
    """
        Permite gaurdar un item a pallet, este item contiene calibre, cantidad, tipo de caja
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de item registrado
                         http 400 => Retorna mensaje de error al registrar item
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            caja_object = Caja.objects.get(id_caja=request.data['id_caja'])
            if caja_object.inventario >= request.data['num_cajas']:
                itemPalletSerializer = ItemPalletSimpleSerializer(
                    data=request.data)
                if itemPalletSerializer.is_valid():
                    itemPalletSerializer.save()
                    caja_object.inventario = caja_object.inventario - \
                        request.data['num_cajas']
                    caja_object.save()
                    return Response(
                        {
                            "message": "Item asociado al id_pallet {} registrado".format(request.data['id_pallet']),
                        },
                        status=status.HTTP_201_CREATED,
                    )
            return Response(
                {
                    "message": "Cantidad de cajas a ingresar no válida"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido crear registro pallet"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class GetItemsByIdPallet(APIView):
    """
        Permite obtener items asociados a pallet a partir del id
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna listado en json de los items
                         http 400 => Retorna mensaje de error al no encontrar items con el id solicitado
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_pallet, format=None):
        try:
            itemsPallet = ItemPallet.objects.filter(Q(id_pallet=id_pallet))
            itemsPalletSerializer = ItemPalletFullSerializer(
                itemsPallet, many=True)
            return Response(itemsPalletSerializer.data, status=status.HTTP_200_OK)
        except:
            return Response(
                {"message": "No existe items con el id solicitado"},
                status=status.HTTP_400_BAD_REQUEST
            )


class GetPalletsByIdPalletizado(APIView):
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_palletizado, format=None):
        try:
            pallets = Pallet.objects.filter(Q(id_palletizado=id_palletizado))
            palletsLista = []
            for pallet in pallets:
                itemsPallet = ItemPallet.objects.filter(
                    Q(id_pallet=pallet.id_pallet))
                itemsLista = []

                for item in itemsPallet:

                    productor = {
                        "id_productor": item.id_productor.id_productor,
                        "nombre": item.id_productor.nombre,
                        "apellido": item.id_productor.apellido,
                        "email": item.id_productor.email,
                        "direccion": item.id_productor.direccion,
                        "telefono": item.id_productor.telefono
                    }

                    newItem = {
                        "id_item_pallet": item.id_item_pallet,
                        "productor": productor,
                        "tipo_caja": item.tipo_caja,
                        "num_cajas": item.num_cajas,
                        "calibre": item.calibre,
                        "id_pallet": item.id_pallet.id_pallet,
                        # "id_usuario": item.id_usuario.id,
                        "id_caja": item.id_caja.id_caja
                    }

                    itemsLista.append(newItem)

                pallet_object = {
                    "id_pallet": pallet.id_pallet,
                    "tipo_pitahaya": pallet.tipo_pitahaya,
                    "id_cliente": pallet.id_cliente.id_cliente,
                    "id_palletizado": pallet.id_palletizado.id_palletizado,
                    "items": itemsLista
                }

                palletsLista.append(pallet_object)

            return Response(palletsLista, status=status.HTTP_200_OK)
        except:
            return Response(
                {"message": "No existe pallets con el id solicitado"},
                status=status.HTTP_400_BAD_REQUEST
            )


class DeleteItemPallet(APIView):
    # permission_classes = [IsAuthenticated]

    def delete(self, request, id_item_pallet, format=None):
        try:
            itemPallet = ItemPallet.objects.get(id_item_pallet=id_item_pallet)
            cantidad = itemPallet.num_cajas
            id_caja = itemPallet.id_caja.id_caja
            caja_object = Caja.objects.get(id_caja=id_caja)
            caja_object.inventario = caja_object.inventario + cantidad
            caja_object.save()
            itemPallet.delete()
            return Response(
                {"message": "Se elimino item pallet"},
                status=status.HTTP_200_OK
            )
        except:
            return Response(
                {"message": "No existe items con el id solicitado"},
                status=status.HTTP_400_BAD_REQUEST
            )


class GetFinalPalletizadoStateOpen(APIView):
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        try:
            palletizadoObject = Palletizado.objects.filter(
                estado=False).latest('id_palletizado')

            if palletizadoObject:
                return Response(
                    {"id_palletizado": palletizadoObject.id_palletizado},
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"id_palletizado": None},
                status=status.HTTP_200_OK
            )


class ChangeStateOpenPalletizado(APIView):
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_palletizado, format=None):
        try:
            palletizadoObject = Palletizado.objects.get(
                id_palletizado=id_palletizado)

            if palletizadoObject:
                palletizadoObject.estado = True
                palletizadoObject.save()
                return Response(
                    {"message": "Palletizado finalizado"},
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"message": "No existe palletizado con el id solicitado"},
                status=status.HTTP_400_BAD_REQUEST
            )
