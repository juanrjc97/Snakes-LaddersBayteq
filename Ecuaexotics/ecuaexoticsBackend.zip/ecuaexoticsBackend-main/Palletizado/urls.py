from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path("crear_palletizado/", SavePalletizado.as_view()),
    path("crear_pallet/", SavePallet.as_view()),
    path("crear_item_pallet/", SaveItemPallet.as_view()),
    path('obtener_items_pallet/<str:id_pallet>/', GetItemsByIdPallet.as_view()),
    path('obtener_pallets/<str:id_palletizado>/',
         GetPalletsByIdPalletizado.as_view()),
    path("actualizar_cliente_pallet/<str:id_pallet>/",
         UpdateClienteInPallet.as_view()),
    path("eliminar_item_pallet/<str:id_item_pallet>/", DeleteItemPallet.as_view()),
    path("get_final_palletizado/", GetPalletizado.as_view()),
    path("final_palletizado_state_open/",
         GetFinalPalletizadoStateOpen.as_view()),
    path("finalizar_palletizado/<str:id_palletizado>/",
         ChangeStateOpenPalletizado.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
