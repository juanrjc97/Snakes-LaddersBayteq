from Calibrado.models import Caja
from django.db import models
from datetime import datetime
from Cliente.models import Cliente
from Usuario.models import Usuario
from Productor.models import Productor


class Palletizado(models.Model):
    id_palletizado = models.AutoField(primary_key=True, unique=True)
    fecha = models.DateTimeField(
        default=datetime.now, verbose_name="Fecha")
    estado = models.BooleanField(default=False, verbose_name="Estado")
    id_usuario = models.ForeignKey(
        Usuario, on_delete=models.PROTECT, verbose_name="Usuario")

    class Meta:
        verbose_name = "Palletizado"
        verbose_name_plural = "Palletizados"

    def __str__(self):
        return '{} {}'.format(self.id_palletizado, self.fecha)


class Pallet(models.Model):
    yellow = "Yellow Dragon Fruit"
    red = "Red Dragon Fruit"

    tipos_pitahaya = [
        (yellow, "Yellow Dragon Fruit"),
        (red, "Red Dragon Fruit"),
    ]

    id_pallet = models.AutoField(primary_key=True, unique=True)
    tipo_pitahaya = models.CharField(
        choices=tipos_pitahaya, default=red, max_length=50, verbose_name="Tipo pitahaya")
    fecha = models.DateTimeField(
        default=datetime.now, verbose_name="Fecha")
    id_cliente = models.ForeignKey(
        Cliente, on_delete=models.PROTECT, verbose_name="Cliente")
    id_palletizado = models.ForeignKey(
        Palletizado, on_delete=models.CASCADE, verbose_name="Palletizado")

    class Meta:
        verbose_name = "Pallet"
        verbose_name_plural = "Pallets"

    def __str__(self):
        return '{} {} {}'.format(self.id_pallet, self.fecha, self.id_cliente.nombre)


class ItemPallet(models.Model):
    cb4 = "Carton Box 4.5 kg net weight"
    cb2 = "Carton Box 2.5 kg net weight"

    tipos_caja = [
        (cb4, "Carton Box 4.5 kg net weight"),
        (cb2, "Carton Box 2.5 kg net weight"),
    ]

    id_item_pallet = models.AutoField(primary_key=True, unique=True)
    tipo_caja = models.CharField(
        choices=tipos_caja, default=cb4, max_length=50, verbose_name="Tipo caja")
    num_cajas = models.IntegerField()
    calibre = models.CharField(max_length=10, verbose_name="Tipo calibre")
    id_pallet = models.ForeignKey(
        Pallet, on_delete=models.CASCADE, verbose_name="Pallet", null=True, default=None)
    id_productor = models.ForeignKey(
        Productor, on_delete=models.PROTECT, verbose_name="Productor")
    id_usuario = models.ForeignKey(
        Usuario, on_delete=models.PROTECT, verbose_name="Usuario")
    id_caja = models.ForeignKey(
        Caja, on_delete=models.CASCADE, blank=True, null=True, verbose_name="Caja"
    )

    class Meta:
        verbose_name = "Item Pallet"
        verbose_name_plural = "Items Pallet"

    def __str__(self):
        return '{} {} {} {}'.format(self.id_item_pallet, self.tipo_caja, self.id_productor.nombre, self.id_productor.apellido)
