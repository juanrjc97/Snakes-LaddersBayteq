from django.apps import AppConfig


class CalibradoConfig(AppConfig):
    name = 'Calibrado'
