from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path("crear_calibrado/", SaveCalibrado.as_view()),
    path("actualizar_calibrado/<str:id_bodega>/", UpdateItemsCalibre.as_view()),
    path("cajas_disponibles/<str:id_pallet>/", GetCajasDisponibles.as_view()),
    path("obtener_cajas/<str:id_bodega>/", GetItemsCalibre.as_view()),
    path("obtener_liquidaciones/<str:id_productor>/",
         GetLiquidacionesByProductor.as_view()),

    path("actualizar_item_liquidacion/<str:id_item_liquidacion>/",
         UpdateItemLiquidacion.as_view()),
    path("actualizar_info_liquidacion/<str:id_calibrado>/",
         UpdateInfoLiquidacion.as_view()),
    path("actualizar_estado_liquidacion/<str:id_calibrado>/",
         UpdateEstadoLiquidacion.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
