from django.db import models
from datetime import datetime
from Bodega.models import Bodega
from Usuario.models import Usuario


class Calibrado(models.Model):
    id_calibrado = models.AutoField(primary_key=True, unique=True)
    fecha = models.DateTimeField(
        default=datetime.now, verbose_name="Fecha Calibrado")
    fecha_pago = models.DateField(
        blank=True, null=True, verbose_name="Fecha Liquidacion")
    # new code
    estado = models.BooleanField(default=False, verbose_name="Estado")
    num_liquidacion = models.CharField(
        max_length=20, blank=True, null=True, verbose_name="Nº Liquidación")
    direccion = models.CharField(
        max_length=150, blank=True, null=True, verbose_name="Dirección")
    destino = models.CharField(
        max_length=150, blank=True, null=True, verbose_name="Destino")
    subtotal = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Subotal"
    )
    iva = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="IVA"
    )
    total = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Total"
    )
    # end code
    id_usuario = models.ForeignKey(
        Usuario, on_delete=models.PROTECT, verbose_name="Usuario")
    id_bodega = models.ForeignKey(
        Bodega, on_delete=models.CASCADE, verbose_name="Bodega")

    class Meta:
        verbose_name = "Calibrado"
        verbose_name_plural = "Calibrados"

    def __str__(self):
        return '{} {}'.format(self.fecha, self.id_bodega.id_productor.nombre)


class Caja(models.Model):
    cb4 = "Carton Box 4.5 kg net weight"
    cb2 = "Carton Box 2.5 kg net weight"

    tipos_caja = [
        (cb4, "Carton Box 4.5 kg net weight"),
        (cb2, "Carton Box 2.5 kg net weight"),
    ]

    id_caja = models.AutoField(primary_key=True, unique=True)
    num_cajas = models.IntegerField()
    inventario = models.IntegerField(default=0)
    tipo_caja = models.CharField(
        choices=tipos_caja, default=cb4, max_length=50, verbose_name="Tipo caja")
    calibre = models.CharField(max_length=10, verbose_name="Tipo calibre")
    # new code
    precio = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Precio"
    )
    # end code
    id_calibrado = models.ForeignKey(
        Calibrado, on_delete=models.CASCADE, verbose_name="Calibrado")

    class Meta:
        verbose_name = "Caja"
        verbose_name_plural = "Cajas"

    def __str__(self):
        return '{} {} {} {}'.format(self.num_cajas, self.tipo_caja, self.calibre, self.id_calibrado.id_bodega.id_productor.nombre)
