from Palletizado.models import Pallet
from .models import Calibrado, Caja
from .serializers import CalibradoSimpleSerializer, CajaSimpleSerializer
from Bodega.models import Bodega
from Productor.serializers import ProductorSerializer
from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
# from ConfigEmail.BuildBodyEmail import _bodyFinishCalibradoProcess
# from ConfigEmail.EmailBackend import EmailBackend


class SaveCalibrado(APIView):
    """
        Permite guardar cajas de calibrado asociado a las cajas de un productor previamente guardado
        como bitacora
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de calibre guardado
                         http 400 => Retorna mensaje de error al guardar calibre.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            calibradoData = request.data['calibrado']
            tipo_caja = request.data['tipo_caja']
            object_calibrado = {
                "id_usuario": calibradoData['id_usuario'],
                "id_bodega": calibradoData['id_bodega']
            }

            calibradoSerializer = CalibradoSimpleSerializer(
                data=object_calibrado)

            if calibradoSerializer.is_valid():
                calibrado = calibradoSerializer.save()

                lista_cajas = []
                for object_tipo in tipo_caja:
                    for caja in object_tipo['calibres']:
                        if caja['cantidad'] > 0:
                            object_caja = {
                                "num_cajas": caja['cantidad'],
                                "tipo_caja": object_tipo['name_tipo_caja'],
                                "calibre": caja['calibre'].split('-')[1],
                                "inventario": caja['cantidad'],
                                "id_calibrado": calibrado.id_calibrado
                            }
                            lista_cajas.append(object_caja)

                cajasSerializer = CajaSimpleSerializer(
                    data=lista_cajas, many=True)

                if cajasSerializer.is_valid():
                    calibresL = cajasSerializer.save()
                    bodega = Bodega.objects.get(
                        id_bodega=calibradoData['id_bodega'])
                    bodega.estado = "Calibrado"
                    bodega.save()

                    return Response(
                        {
                            "message": "Se ha guardado las cajas por calibre de un productor correctamente",
                        },
                        status=status.HTTP_201_CREATED,
                    )
        except:
            return Response(
                {
                    "message": "No se ha podido crear el registro"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class GetCajasDisponibles(APIView):
    """
        Permite obtener las cajas de caibre disponibles en el inventario en base al id del pallet que contiene
        información de tipo de pitahaya.
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna lista de cajas de calibres por productor
                         http 400 => Retorna mensaje de error al no poder cargar cajas de calibre
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_pallet, format=None):
        try:
            palletObj = Pallet.objects.get(id_pallet=id_pallet)
            dictProductores = {}
            bodegaList = Bodega.objects.filter(
                Q(tipo_pitahaya=palletObj.tipo_pitahaya))
            calibreList = Calibrado.objects.filter(
                id_bodega__in=[bode.id_bodega for bode in bodegaList])
            cajas_object = Caja.objects.filter(
                Q(inventario__gt=0) & Q(id_calibrado__in=[cali.id_calibrado for cali in calibreList]))

            for caja in cajas_object:
                productor = caja.id_calibrado.id_bodega.id_productor
                if not productor.id_productor in dictProductores.keys():
                    objectProductor = {
                        "id_productor": productor.id_productor,
                        "nombre": productor.nombre,
                        "apellido": productor.apellido,
                        "email": productor.email,
                        "direccion": productor.direccion,
                        "telefono": productor.telefono,
                    }

                    dictProductores[productor.id_productor] = {
                        "productor": objectProductor,
                        "tipo_caja": [
                            {
                                "tipo": "Carton Box 2.5 kg net weight",
                                "cajas": []
                            },
                            {
                                "tipo": "Carton Box 4.5 kg net weight",
                                "cajas": []
                            }
                        ]
                    }

            for caja in cajas_object:
                tipo = caja.tipo_caja
                productor = caja.id_calibrado.id_bodega.id_productor.id_productor
                itemCaja = {
                    'id_caja': caja.id_caja,
                    'inventario': caja.inventario,
                    'calibre': caja.calibre
                }
                if tipo == 'Carton Box 2.5 kg net weight':
                    dictProductores[productor]['tipo_caja'][0]['cajas'].append(
                        itemCaja)
                elif tipo == 'Carton Box 4.5 kg net weight':
                    dictProductores[productor]['tipo_caja'][1]['cajas'].append(
                        itemCaja)

            return Response(dictProductores.values(), status=status.HTTP_200_OK)
        except:
            return Response({"message": "No existe pallet con dicho id"}, status=status.HTTP_400_BAD_REQUEST)


class GetItemsCalibre(APIView):
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_bodega, format=None):
        try:
            dictTipoCaja = {
                "Caja 2.5": {
                    "tipo_caja": "Carton Box 2.5 kg net weight",
                    "calibres": []
                },
                "Caja 4.5": {
                    "tipo_caja": "Carton Box 4.5 kg net weight",
                    "calibres": []
                }
            }
            calibrado_object = Calibrado.objects.get(id_bodega=id_bodega)

            cajas_object = Caja.objects.filter(
                Q(id_calibrado=calibrado_object.id_calibrado))

            for caja in cajas_object:
                cajaItem = {
                    "id_caja": caja.id_caja,
                    "calibre": 'C-' + caja.calibre,
                    "cantidad": caja.num_cajas
                }
                if caja.tipo_caja == 'Carton Box 2.5 kg net weight':
                    dictTipoCaja['Caja 2.5']['calibres'].append(cajaItem)

                elif caja.tipo_caja == 'Carton Box 4.5 kg net weight':
                    dictTipoCaja['Caja 4.5']['calibres'].append(cajaItem)

            return Response(dictTipoCaja.values(), status=status.HTTP_200_OK)
        except:
            return Response({"message": "No existe calibrado con el id solicitado"}, status=status.HTTP_400_BAD_REQUEST)


class UpdateItemsCalibre(APIView):
    """
        Permite actualizar información de una caja de calibre, si un tipo de calibre no existe se procede
        a crear el objecto caja
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de item de calibre actualizado
                         http 400 => Retorna mensaje de error al actualizar item de calibre.
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]
    def put(self, request, id_bodega, format=None):

        try:
            # print(request.data)
            calibradoData = request.data['calibrado']
            tipo_caja = request.data['tipo_caja']

            calibrado = Calibrado.objects.get(id_bodega=id_bodega)

            lista_cajas = []
            for object_tipo in tipo_caja:
                for caja in object_tipo['calibres']:
                    # if caja['cantidad'] > 0:
                    object_caja = {
                        "num_cajas": caja['cantidad'],
                        "tipo_caja": object_tipo['name_tipo_caja'],
                        "calibre": caja['calibre'].split('-')[1],
                        "inventario": caja['cantidad'],
                        "id_calibrado": calibrado.id_calibrado
                    }
                    if caja['id_caja'] > 0:
                        cajaItemBd = Caja.objects.get(
                            id_caja=caja['id_caja'])
                        if caja['cantidad'] == 0:
                            cajaItemBd.delete()
                        else:
                            if cajaItemBd.num_cajas > caja['cantidad']:
                                cajaItemBd.inventario += cajaItemBd.num_cajas - \
                                    caja['cantidad']
                            else:
                                cajaItemBd.inventario += caja['cantidad'] - \
                                    cajaItemBd.num_cajas
                            cajaItemBd.num_cajas = caja['cantidad']
                            cajaItemBd.save()
                    else:
                        if caja['cantidad'] > 0:
                            lista_cajas.append(object_caja)
            cajasSerializer = CajaSimpleSerializer(
                data=lista_cajas, many=True)

            if cajasSerializer.is_valid():
                cajasSerializer.save()
                bodega = Bodega.objects.get(
                    id_bodega=calibradoData['id_bodega'])
                bodega.estado = "Calibrado"
                bodega.save()
                return Response(
                    {
                        "message": "Se ha actualziado las cajas por calibre de un productor correctamente",
                    },
                    status=status.HTTP_201_CREATED,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido actualizar las cajas de calibre"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class GetLiquidacionesByProductor(APIView):
    """
        Permite obtener listado de liquidaciones de un productor en base al id del mismo
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna listado de liquidaciones
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_productor, format=None):

        listBodega = Bodega.objects.filter(
            Q(id_productor=id_productor)).order_by('-fecha')
        data = []
        if len(listBodega) > 0:
            idsCalibrado = []
            for bodega in listBodega:
                try:
                    calibrado = Calibrado.objects.get(
                        id_bodega=bodega.id_bodega)
                    idsCalibrado.append(calibrado.id_calibrado)
                except:
                    pass
            listLiquidaciones = Calibrado.objects.filter(
                id_calibrado__in=[idc for idc in idsCalibrado])
            if len(listLiquidaciones) > 0:
                for liq in listLiquidaciones:
                    listItems = Caja.objects.filter(
                        Q(id_calibrado=liq.id_calibrado))
                    dataLiquidaciones = {
                        liq.id_calibrado: {
                            "calibrado": {
                                "id_calibrado":    liq.id_calibrado,
                                "fecha":           liq.fecha,
                                "fecha_pago":      liq.fecha_pago,
                                "estado":          liq.estado,
                                "num_liquidacion": liq.num_liquidacion,
                                "direccion":       liq.direccion,
                                "destino":         liq.destino,
                                "subtotal":        liq.subtotal,
                                "iva":             liq.iva,
                                "tipo_pitahaya":   liq.id_bodega.tipo_pitahaya,
                                "total": liq.total
                            },
                            "Carton Box 2.5 kg net weight": {"tipo": "Carton Box 2.5 kg net weight", "items": []},
                            "Carton Box 4.5 kg net weight": {"tipo": "Carton Box 4.5 kg net weight", "items": []}
                        }
                    }
                    for item in listItems:
                        if '2.5' in item.tipo_caja:
                            kg = item.num_cajas * 2.5
                        if '4.5' in item.tipo_caja:
                            kg = item.num_cajas * 4.5
                        item_object = {
                            "id_item_liquidacion": item.id_caja,
                            "num_cajas":  item.num_cajas,
                            "inventario": item.inventario,
                            "tipo_caja":  item.tipo_caja,
                            "calibre": item.calibre,
                            "precio": item.precio,
                            "kg": round(kg, 2),
                            "id_calibrado": liq.id_calibrado
                        }
                        dataLiquidaciones[liq.id_calibrado][item.tipo_caja]['items'].append(
                            item_object)
                    valueData = dataLiquidaciones.values()
                    for dat in valueData:
                        infoData = {
                            "calibrado": dat['calibrado'],
                            "tipos": [
                                dat['Carton Box 2.5 kg net weight'],
                                dat['Carton Box 4.5 kg net weight']
                            ]
                        }
                        data.append(infoData)
        return Response(
            data,
            status=status.HTTP_200_OK,
        )


class UpdateItemLiquidacion(APIView):
    """
        Permite actualizar información de items de liquidaciones como son el precio a pitahaya
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de información actualizada
                         http 400 => Retorna mensaje de error al zctualizar información
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_item_liquidacion, format=None):
        try:
            precio = round(request.data['precio'], 2)
            cajaObject = Caja.objects.get(id_caja=id_item_liquidacion)
            if cajaObject:
                cajaObject.precio = precio
                cajaObject.save()
                cajaList = Caja.objects.filter(
                    Q(id_calibrado=cajaObject.id_calibrado.id_calibrado))
                subtotalSum = 0
                for cajaItem in cajaList:
                    kg = 0
                    if '2.5' in cajaItem.tipo_caja:
                        kg = cajaItem.num_cajas * 2.5
                    if '4.5' in cajaItem.tipo_caja:
                        kg = cajaItem.num_cajas * 4.5
                    precioNew = float(cajaItem.precio)
                    calcPrecio = kg * precioNew
                    subtotalSum += calcPrecio

                calibradoObject = Calibrado.objects.get(
                    id_calibrado=cajaObject.id_calibrado.id_calibrado)
                if calibradoObject:
                    calibradoObject.subtotal = round(subtotalSum, 2)
                    ivaCal = (subtotalSum * float(calibradoObject.iva)) / 100
                    total = subtotalSum - ivaCal
                    calibradoObject.total = round(total, 2)
                    calibradoObject.save()
            return Response(
                {
                    "message": "Actualizado Item"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido crear actualizar el precio del item"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class UpdateInfoLiquidacion(APIView):
    """
        Permite actualizar informacion de un item liquidacion, el campo a actualizar son el precio a
        pagarle por caja de calibre al productor
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de actualización realizada
                         http 400 => Retorna mensaje de error al actualizar
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_calibrado, format=None):
        try:
            calibradoObject = Calibrado.objects.get(id_calibrado=id_calibrado)
            if calibradoObject:
                calibradoObject.fecha_pago = request.data['fecha_pago']
                calibradoObject.direccion = request.data['direccion']
                calibradoObject.destino = request.data['destino']
                calibradoObject.num_liquidacion = request.data['num_liquidacion']
                calibradoObject.save()
            return Response(
                {
                    "message": "Información de liquidación actualizada"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido crear actualizar información de liquidación"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class UpdateEstadoLiquidacion(APIView):
    """
        Permite cambiar de estado a finalizado una liquidación
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de liquidación finalizada
                         http 400 => Retorna mensaje de error al actualizar estado de liquidación
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_calibrado, format=None):
        try:
            calibradoObject = Calibrado.objects.get(id_calibrado=id_calibrado)
            if calibradoObject:
                calibradoObject.estado = request.data['estado']
                calibradoObject.save()
            return Response(
                {
                    "message": "Liquidación finalizada"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido finalizar liquidación"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


# def messsageEmail(asunt, body, emailDst, calibres):
#     try:
#         listToEmail = []
#         email_from = 'Ecuaexotics' + ' <settings.EMAIL_HOST_USER>'
#         listToEmail += ['bryan.tutiven.2@gmail.com']
#         contentEmail = EmailBackend(
#             asunt, body, email_from,  listToEmail)
#         contentEmail.sendEmailHtml('calibre', calibres)
#     except:
#         pass
