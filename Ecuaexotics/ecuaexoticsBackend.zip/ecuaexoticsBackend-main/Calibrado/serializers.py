from .models import Calibrado, Caja
from rest_framework import serializers
from Productor.serializers import ProductorSerializer
from Usuario.serializers import UsuarioSerializer


class CalibradoSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = Calibrado
        fields = [
            'id_calibrado',
            'fecha',
            'id_usuario',
            'id_bodega'
        ]


class CajaSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = Caja
        fields = [
            "id_caja",
            "num_cajas",
            "inventario",
            "tipo_caja",
            "calibre",
            "id_calibrado"
        ]
