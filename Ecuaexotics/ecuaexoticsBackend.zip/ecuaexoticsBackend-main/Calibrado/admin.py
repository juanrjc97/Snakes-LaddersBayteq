from django.contrib import admin
from .models import Calibrado, Caja

myModels = [Calibrado, Caja]
admin.site.register(myModels)
