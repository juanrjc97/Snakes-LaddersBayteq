import os
import base64
from .serializers import ControlCalidadSimpleSerializer, ImagenControlCalidadSimpleSerializer
from .models import ControlCalidad, ImagenControlCalidad
from Calibrado.models import Caja, Calibrado
from Bodega.models import Bodega
from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from django.conf import settings
from ConfigEmail.BuildBodyEmail import _bodyFinishControlProcess, _bodyFinishCalibradoProcess
from ConfigEmail.EmailBackend import EmailBackend


class SaveControlCalidad(APIView):
    """
        Permite guardar un nuevo control de calidad con observaciones e imagenes
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de control de calidad guardado
                         http 400 => Retorna mensaje de error al guardar control de calidad
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            controlSerializer = ControlCalidadSimpleSerializer(
                data={
                    "observacion": request.data['observacion'],
                    "id_bodega": request.data['id_bodega']
                })
            if controlSerializer.is_valid():
                controlObject = controlSerializer.save()
                cant = int(request.data['cantidad'])
                if cant > 0:
                    for i in range(1, cant + 1):
                        nameClave = 'imagen_'+str(i)
                        imagenSerializer = ImagenControlCalidadSimpleSerializer(
                            data={
                                "imagen": request.data[nameClave],
                                "id_control": controlObject.id_control
                            }
                        )
                        if imagenSerializer.is_valid():
                            imagenSerializer.save()

                bodegaObject = Bodega.objects.get(
                    id_bodega=request.data['id_bodega'])
                bodegaObject.estado = 'Finalizado'
                bodegaObject.save()

                calibradoObj = Calibrado.objects.get(
                    id_bodega=bodegaObject.id_bodega)
                productor = bodegaObject.id_productor
                calibresL = Caja.objects.filter(
                    Q(id_calibrado=calibradoObj.id_calibrado))
                body = _bodyFinishCalibradoProcess(productor, bodegaObject)
                asunt = 'Notificaciones Ecuaexotics'

                messsageEmail(asunt, body, productor.email,
                              calibresL, controlObject)

                return Response(
                    {
                        "message": "Se ha guardado el control de calidad",
                    },
                    status=status.HTTP_201_CREATED,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido crear el registro de control de calidad"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


def messsageEmail(asunt, body, emailDst, calibres, controlObject):
    try:
        listToEmail = []
        email_from = 'Ecuaexotics' + ' <settings.EMAIL_HOST_USER>'
        listToEmail += [emailDst]
        contentEmail = EmailBackend(
            asunt, body, email_from,  listToEmail)
        contentEmail.sendEmailHtml('calibre', calibres, controlObject)
    except:
        pass


class GetInfoControlCalidadByBodega(APIView):
    """
        Permite obtener el control de calidad asociado con una bitacora de un productor
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna información de control de calidad asociado a una bitacora
                         http 400 => Retorna mensaje de error al no encontrar la bitacora
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_bodega, format=None):
        try:
            controlObject = ControlCalidad.objects.get(id_bodega=id_bodega)
            if controlObject:
                bodegaObject = Bodega.objects.get(id_bodega=id_bodega)
                dataObject = {
                    "fecha": controlObject.fecha,
                    "observacion": controlObject.observacion,
                    "num_gavetas": bodegaObject.num_gavetas,
                    "tipo_pitahaya": bodegaObject.tipo_pitahaya
                }
                imgsControl = ImagenControlCalidad.objects.filter(
                    Q(id_control=controlObject.id_control))
                dataImgControl = []

                if len(imgsControl) > 0:
                    for img in imgsControl:
                        pathImg = 'media/' + str(img.imagen)
                        extension = str(img.imagen).split('.')[-1]
                        imgSend = image_as_base64(pathImg, format=extension)
                        if imgSend:
                            imgObject = {
                                "imagen": imgSend
                            }
                            dataImgControl.append(imgObject)

                dataObject["images"] = dataImgControl

                return Response(
                    dataObject,
                    status=status.HTTP_200_OK,
                )
        except:
            return Response(
                {
                    "message": "No se ha podido cargar el control de calidad con el id solicitado"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


"""
    Permite convertir una imagen en formato png, jpg a base64
"""


def image_as_base64(image_file, format='png'):

    BASE_DIR_Path = settings.BASE_DIR
    newPath = os.path.join(BASE_DIR_Path, image_file)
    if not os.path.isfile(newPath):
        return None

    encoded_string = ''
    with open(newPath, 'rb') as img_f:
        encoded_string = base64.b64encode(img_f.read()).decode('utf-8')
    return 'data:image/%s;base64,%s' % (format, encoded_string)
