from django.db import models
from datetime import datetime
from Bodega.models import Bodega


class ControlCalidad(models.Model):
    id_control = models.AutoField(primary_key=True, unique=True)
    fecha = models.DateTimeField(
        default=datetime.now, verbose_name="Fecha Control")
    observacion = models.TextField(verbose_name="Observación")
    id_bodega = models.ForeignKey(
        Bodega, on_delete=models.CASCADE, verbose_name="Bodega")

    class Meta:
        verbose_name = "Control calidad"
        verbose_name_plural = "Controles calidad"

    def __str__(self):
        return '{}'.format(self.id_bodega.id_productor.nombre)


class ImagenControlCalidad(models.Model):
    id_imagen = models.AutoField(primary_key=True, unique=True)
    imagen = models.ImageField(
        upload_to="images/%Y/%m/", verbose_name="Imagen")
    id_control = models.ForeignKey(
        ControlCalidad, on_delete=models.CASCADE, verbose_name="Control Calidad")

    class Meta:
        verbose_name = "Imagen control calidad"
        verbose_name_plural = "Imagénes control calidad"

    def __str__(self):
        return '{}'.format(self.id_control)
