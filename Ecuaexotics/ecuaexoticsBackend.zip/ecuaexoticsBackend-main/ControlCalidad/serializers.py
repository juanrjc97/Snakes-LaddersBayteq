from .models import ControlCalidad, ImagenControlCalidad
from rest_framework import serializers


class ControlCalidadSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = ControlCalidad
        fields = [
            'observacion',
            'id_bodega'
        ]


class ImagenControlCalidadSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = ImagenControlCalidad
        fields = [
            'imagen',
            'id_control'
        ]
