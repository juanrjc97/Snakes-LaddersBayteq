from django.apps import AppConfig


class ControlcalidadConfig(AppConfig):
    name = 'ControlCalidad'
