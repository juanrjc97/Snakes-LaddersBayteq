from django.contrib import admin
from .models import ControlCalidad, ImagenControlCalidad

myModels = [ControlCalidad, ImagenControlCalidad]
admin.site.register(myModels)
