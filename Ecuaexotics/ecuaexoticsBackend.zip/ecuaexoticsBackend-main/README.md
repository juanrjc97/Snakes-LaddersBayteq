# Ecuaexotics Backend

Aplicación Django que funciona como servidor, dispone de endpoints o API Rest para que la aplicación frontend puede a acceder a recursos.

## Instalar requerimientos de librerías en el entorno local

Usar el siguiente comando sobre la carpeta raíz.

```bash
pip install -r requirements.txt
```

## Generar archivo requirements.txt

Usar el siguiente comando sobre la carpeta raíz para generar archivo requirements

```bash
pip freeze > requirements.txt
```

## Realizar migraciones de los modelos a la base de datos

```bash
python manage.py makemigrations
python manage.py migrate
```

## Crear el admin django

```bash
python manage.py createsuperuser
```

# Endpoints

## APIs Bodega

Obtener lista de bitacoras (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/bodega/obtener_bitacoras/
```

Guardar bitácora (POST), ejemplo:

{
"num_gavetas": 10,
"estado": "Bodega",
"tipo_pitahaya": "Red Dragon Fruit",
"id_productor": 1,
"id_usuario": 1
}

```bash
https://ecuaexotics.pythonanywhere.com/api/bodega/crear_bitacora/
```

Obtener listado de bitacoras en vista del operador de calibre(GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/bodega/obtener_todas_bitacoras/
```

Actualizar numero de gavetas en bodega (PUT) Ejemplo:

{
"num_gavetas": 70000
}

id_bodega es un número

```bash
https://ecuaexotics.pythonanywhere.com/api/bodega/actualizar_bitacora/${id_bodega}/
```

Obtener gavetas por id_productor (GET)

2 -> id_productor

```bash
https://ecuaexotics.pythonanywhere.com/api/bodega/obtener_bitacoras_by_productor/2/
```

## APIs Productor

Obtener listado de productores (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/productor/obtener_productores/
```

Obtener listado completo de productores (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/productor/obtener_productores_todos/
```

Obtener productor por id (GET)

1 -> id_productor

```bash
https://ecuaexotics.pythonanywhere.com/api/productor/obtener_productor_by_id/1/
```

Guardar Productor (POST)

Ejemplo de data a enviar

{
"nombre": "Cesar21",
"apellido": "Acosta21",
"email": "cesaracosta21@gmail.com",
"direccion": "Daule21",
"telefono": "0988097921",
"activo": true
}

```bash
https://ecuaexotics.pythonanywhere.com/api/productor/guardar_productor/
```

Actualizar productor (PUT)

Ejemplo de data a enviar
{
"nombre": "Cesar2",
"apellido": "Acosta2",
"email": "cesaracosta2@gmail.com",
"direccion": "Daule2",
"telefono": "0988097922",
"activo": true
}

1 -> id_productor

```bash
https://ecuaexotics.pythonanywhere.com/api/productor/actualizar_productor_by_id/1/
```

## APIs Cliente

Obtener listado de clientes (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/cliente/obtener_clientes/
```

Obtener listado completo de clientes (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/cliente/obtener_clientes_todos/
```

Obtener cliente por id (GET)

2 -> id_cliente

```bash
https://ecuaexotics.pythonanywhere.com/api/cliente/obtener_cliente_by_id/2/
```

Guardar Cliente (POST)

Ejemplo de data a enviar

{
"nombre": "Test112",
"apellido": "Test12",
"email": "test12@gmail.com",
"pais": "cdsvkjb12",
"direccion": "cbdsvb12",
"activo": true,
"destino_orden": "vbdsvbk12",
"notify_address": "hvbdsbk12",
"notify": "vdsbkvjb12",
"telefono": "490347212"
}

```bash
https://ecuaexotics.pythonanywhere.com/api/cliente/guardar_cliente/
```

Actualizar cliente (PUT)

Ejemplo de data a enviar
{
"nombre": "Test111",
"apellido": "Test11",
"email": "test11@gmail.com",
"pais": "cdsvkjb11",
"direccion": "cbdsvb11",
"activo": true,
"destino_orden": "vbdsvbk11",
"notify_address": "hvbdsbk11",
"notify": "vdsbkvjb11",
"telefono": "490347211"
}

2 -> id_cliente

```bash
https://ecuaexotics.pythonanywhere.com/api/cliente/actualizar_cliente_by_id/2/
```

## APIs Calibrado

Obtener Cajas disponibles por productor (GET)

1 -> id_pallet

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/cajas_disponibles/1/
```

Guardar cajas de calibrado (POST)

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/crear_calibrado/
```

Obtener cajas de calibrado por id de bodega (GET)

1 -> id_bodega

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/obtener_cajas/1/
```

## APIs Palletizado

Crear objecto palletizado (POST)

{
"id_usuario": 1
}

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/crear_palletizado/
```

Crear objecto pallet (POST)

{
"tipo_pitahaya": "Yellow Dragon Fruit",
"id_cliente": 1,
"id_palletizado": 1
}

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/crear_pallet/
```

Crear objecto item pallet (POST)

{
"tipo_caja": "Carton Box 4.5 kg net weight",
"num_cajas": 30,
"calibre": "5",
"id_pallet": 1,
"id_productor": 1,
"id_usuario": 1,
"id_caja": 1
}

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/crear_item_pallet/
```

Obtener items pallet (GET)

2 -> id_pallet

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/obtener_items_pallet/2/
```

Eliminar Item Pallet (DELETE)

1 -> id_item_pallet

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/eliminar_item_pallet/1/
```

Obtener pallets por id palletizado (GET)

2 -> id_palletizado

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/obtener_pallets/2/
```

Actualizar Cliente en Pallet (PUT)
Ejemplo -> {
"id_cliente": 2
}

2 -> id_pallet

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/actualizar_cliente_pallet/2/
```

Obtener último palletizado (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/get_final_palletizado/
```

Obtener último palletizado con estado abierto en el frontend (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/final_palletizado_state_open/
```

Finalizar el último Palletizado (PUT)

8 -> id_palletizado

```bash
https://ecuaexotics.pythonanywhere.com/api/palletizado/finalizar_palletizado/8/
```

## APIs Usuario

Obtener lista de usuarios (GET)

```bash
https://ecuaexotics.pythonanywhere.com/api/usuario/users/
```

Update Usuario (PUT)

2 -> id_usuario
Ejemplo - > {
"email": "test1@gmail.com",
"password": "test1",
"username": "test1",
"nombre": "TestN11",
"apellido": "TestA11",
"rol": "Admin",
"is_active": "True"
}

```bash
https://ecuaexotics.pythonanywhere.com/api/usuario/users-detalle/2/
```

Guardar Usuario (POST)

Ejemplo -> {
"email": "test1@gmail.com",
"password": "test",
"username": "test1",
"nombre": "TestN1",
"apellido": "TestA1",
"rol": "Admin",
"is_active": "True"
}

```bash
https://ecuaexotics.pythonanywhere.com/api/usuario/users/
```

Deshabilitar Usuario (DELETE)

2-> id_usuario

```bash
https://ecuaexotics.pythonanywhere.com/api/usuario/users-detalle/2/
```

Obtener Usuario (Get)

2-> id_usuario

```bash
https://ecuaexotics.pythonanywhere.com/api/usuario/users-detalle/2/
```

## APIs Liquidación

Obtener listado de liquidaciones por productor (GET)

1 -> id_productor

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/obtener_liquidaciones/1/
```

Actualizar item liquidacion (PUT)

{
"precio": 10.5
}

37 -> id_item_liquidacion

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/actualizar_item_liquidacion/37/
```

Actualizar información liquidacion (PUT)

Ejemplo:
Campos importantes: destino, dirección, num_liquidacion, fecha_pago
{
"destino": "Daule",
"direccion": "Calle Rocafuerte by pass",
"estado": false,
"fecha_pago": "2021-08-04",
"fecha": "2021-08-03T23:42:00.968921Z",
"id_calibrado": 5,
"iva": 0,
"num_liquidacion": "102",
"subtotal": 0,
"tipo_pitahaya": "Yellow Dragon Fruit",
"total": 0
}

6 -> id_calibrado

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/actualizar_info_liquidacion/6/
```

Actualizar estado liquidacion (PUT)

Data a enviar:
{
"estado": true
}

6 -> id_calibrado

```bash
https://ecuaexotics.pythonanywhere.com/api/calibrado/actualizar_estado_liquidacion/6/
```

## APIs Documentos

Obtener listado de packing list (GET)

1 -> id_cliente

```bash
https://ecuaexotics.pythonanywhere.com/api/documentos/obtener_packinglist_cliente/1/
```

Obtener listado de facturas o invoice (GET)

1 -> id_cliente

```bash
https://ecuaexotics.pythonanywhere.com/api/documentos/obtener_facturas_cliente/1/
```

Actualizar item factura (PUT)

{
"precio_caja": 10.4
}

1 -> id_item_factura

```bash
https://ecuaexotics.pythonanywhere.com/api/documentos/actualizar_item_factura/1/
```

Actualizar información factura (PUT)

Ejemplo:
Campos importantes: referencia_exportacion, factura_num, fecha
{
"id_factura": 1,
"fecha": "2021-08-05",
"referencia_exportacion": "ref-daule",
"factura_num": "1234567",
"subtotal": 0.0,
"impuesto": 0.0,
"total": 0.0,
"id_cliente": 1,
"id_palletizado": 6
}

1 -> id_factura

```bash
https://ecuaexotics.pythonanywhere.com/api/documentos/actualizar_info_factura/1/
```

Actualizar estado factura (PUT)

Data a enviar:
{
"estado": true
}

1 -> id_factura

```bash
https://ecuaexotics.pythonanywhere.com/api/documentos/actualizar_estado_factura/1/
```

Actualizar información PackingList (PUT)

Ejemplo:
Campos importantes: factura_num, linea_area, awb, fda_num, packing_num, fecha, informacion_extra, estado,
{
"id_packing": 1,
"factura_num": "1928",
"linea_area": "American Airlines",
"awb": "12cb",
"fda_num": "1234",
"packing_num": "1234",
"fecha": "2021-08-05",
"total_peso": 90.0,
"informacion_extra": "-------------",
"estado": true
}

1 -> id_packing

```bash
https://ecuaexotics.pythonanywhere.com/api/documentos/actualizar_info_packinglist/1/
```
