from django.core.mail import EmailMessage
from django.core.mail import EmailMultiAlternatives
from smtplib import SMTPException
from .htmlContentEmail import _contentLiquidacion
from email.mime.image import MIMEImage
import os
from pathlib import Path
from django.conf import settings


class EmailBackend:
    def __init__(self, subject, body, from_email, to_email):
        self.subject = subject
        self.body = body
        self.from_email = from_email
        self.to_email = to_email

    def sendNormalMsg(self, ):

        try:
            msg = EmailMessage(
                self.subject,
                self.body,
                self.from_email,
                self.to_email
            )
            msg.send()

        except SMTPException:
            return 0

    def sendEmailHtml(self, tipo, dataInfo, controlObject):
        try:
            image = 'logo.png'
            BASE_DIR_Path = settings.BASE_DIR
            image_path = os.path.join(BASE_DIR_Path, 'static/'+image)
            image_name = Path(image_path).name
            if tipo == 'calibre':
                data = _contentLiquidacion(
                    image_name, dataInfo, self.body, controlObject)
            else:
                data = _contentLiquidacion(
                    image_name, dataInfo, self.body, controlObject)

            msg = EmailMultiAlternatives(
                self.subject,
                self.body,
                self.from_email,
                self.to_email
            )
            msg.attach_alternative(data, "text/html")
            msg.content_subtype = 'html'
            msg.mixed_subtype = 'related'

            with open(image_path, mode='rb') as f:
                image = MIMEImage(f.read())
                msg.attach(image)
                image.add_header('Content-ID', f"<{image_name}>")
            msg.send()
            return 1
        except SMTPException:
            return 0
