
def _contentLiquidacion(image_name, dataInfo, body, control):
    lineCal = '<table style="width: 90%; border-collapse: collapse;">'
    initTable = (
        '<thead>'
        '<tr>'
        '<th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Calibre</th>'
        '<th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Nº De Cajas</th>'
        '<th style="border: 1px solid #dddddd; text-align: left; padding: 8px;">Tipo de Caja</th>'
        '</tr>'
        '</thead>'
        '<tbody>'
    )
    lineCal += initTable
    totalCa = 0
    for cali in dataInfo:
        totalCa += cali.num_cajas
        row = (
            '<tr>'
            '<td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">' +
            str(cali.calibre) + '</td>'
            '<td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">' +
            str(cali.num_cajas) + '</td>'
            '<td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">' +
            cali.tipo_caja + '</td>'
            '</tr>'
        )
        lineCal += row
    endtable = (
        '<tr>'
        '<td colspan="2" style="border: 1px solid #dddddd; text-align: left; padding: 8px;">'
        '<b>Total de Cajas:</b>'
        '</td>'
        '<td style="border: 1px solid #dddddd; text-align: left; padding: 8px;">'
        + str(totalCa) +
        '</td>'
        '</tr>'
        '</tbody>'
        '</table'
    )
    lineCal += endtable
    observaciones = (
        '<div>'
        '<p><b>Se adjuntan observaciones de sus gavetas:</b></p>'
        '<p>' + str(control.observacion) + '</p>'
        '<p><i>Este correo es generado automáticamente por el Sistema de Trazabilidad de Ecuaexotics</i></p>'
        '</div>'
    )
    data = f"""
                <!doctype html>
                <html>
                <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width">
                <title>LIQUIDACION</title>
                <link href="style.css" rel="stylesheet" type="text/css" />
                </head>
                <body>
                <div>
                {body} 
                </div>
                <div style="display: flex; margin-top: 15px">
                    <div>
                    <img width="100" src='cid:{image_name}' />
                    </div>
                    <div style="padding: 10px 20px; font-size: 10px">
                    <p style="margin: 0px"><b>SBD CIA. LTDA.</b>
                    </p>
                    <p style="margin: 0px">Cdla. Kennedy Vieja s/n</p>
                    <p style="margin: 0px">Edificio: C.C. Comercial Las Vitrinas piso 1, oficina 65</p>
                    <p style="margin: 0px">Guayaquil, Ecuador</p>
                    <p style="margin: 0px">04 2280360 - 04 2097468 - 09 97803339</p>
                    <p style="margin: 0px">sales@ecuaexotics.com</p>
                    </div>
                    <div>
                    <p style="color: #06C581"><b>LIQUIDACION</b></p>
                    <p><b style="color: #06C581">No. &nbsp;</b> ---</p>
                    </div>
                </div>
                <div>
                {lineCal}
                </div>
                {observaciones}
                </body>
                </html>
            """
    return str(data)
