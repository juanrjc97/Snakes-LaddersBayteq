
def _bodyInitProcessBodega(productor, bodega):
    body = (
        'Estimado(a) Productor/a ' + productor.nombre +
        ' ' + productor.apellido + '\n\n'
        'Se le comunica que ha iniciado el procesamiento de sus ' +
        str(bodega.num_gavetas) + ' gavetas.' + '\n\n'
        'Este correo es generado automáticamente por el Sistema de Trazabilidad de Ecuaexotics. \n\n'
    )
    return body


def _bodyFinishCalibradoProcess(productor, bodega):
    body = (
        'Estimado(a) Productor/a ' + productor.nombre +
        ' ' + productor.apellido + '<br/>'
        'Se le comunica que ha finalizado el proceso de calibrado de sus ' +
        str(bodega.num_gavetas) + ' gavetas.' + '<br/>'
        'Se adjunta detalle del calibrado:  <br/>'
    )
    return body


def _bodyFinishControlProcess(productor, control):
    fechaSplit = str(control.fecha).split(' ')[0]
    body = (
        'Estimado(a) Productor/a ' + productor.nombre +
        ' ' + productor.apellido + '\n\n'
        'Se le comunica que ha finalizado el proceso de trazabilidad de sus gavetas' + '\n\n'
        'Fecha: ' + fechaSplit + '\n'
        'Se adjuntan observaciones de sus gavetas: \n'
        '' + control.observacion + '\n\n'
        'Este correo es generado automáticamente por el Sistema de Trazabilidad de Ecuaexotics \n\n'
    )
    return body
