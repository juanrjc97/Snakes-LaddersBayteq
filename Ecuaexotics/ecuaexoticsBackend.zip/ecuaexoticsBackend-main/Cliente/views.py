from .models import Cliente
from .serializers import ClienteSerializer

from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView


class GetListCliente(APIView):
    """
        Permite obtener listado de clientes activos
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna json con todos los clientes
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        clienteObject = Cliente.objects.all().order_by(
            'nombre').filter(Q(activo=True))
        clienteSerializer = ClienteSerializer(
            clienteObject, many=True)
        return Response(clienteSerializer.data, status=status.HTTP_200_OK)


class GetAllListCliente(APIView):
    """
        Permite obtener listado de clientes, indpendiente de si esta activo o no
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna listado de cliente
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        clienteObject = Cliente.objects.all().order_by(
            'nombre')
        clienteSerializer = ClienteSerializer(
            clienteObject, many=True)
        return Response(clienteSerializer.data, status=status.HTTP_200_OK)


class SaveCliente(APIView):
    """
        Permite guardar un nuevo cliente
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de cliente registrado
                         http 400 => Retorna mensaje de error al guardar cliente
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            clienteSerializer = ClienteSerializer(data=request.data)
            if clienteSerializer.is_valid():
                clienteSerializer.save()
                return Response(
                    {"message": "Se ha guardo el cliente correctamente"},
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"message": "No se ha podido crear el cliente"},
                status=status.HTTP_400_BAD_REQUEST
            )


class GetClienteById(APIView):
    """
        Permite obtener información de cliente a partir del id
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna json del cliente solicitado
                         http 400 => Retorna mensaje de error al no encontrar cliente en base al id
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_cliente, format=None):
        try:
            cliente = Cliente.objects.get(id_cliente=id_cliente)
            clienteSerializer = ClienteSerializer(cliente)
            return Response(
                clienteSerializer.data,
                status=status.HTTP_200_OK
            )
        except:
            return Response(
                {"message": "No existe cliente con id " + id_cliente},
                status=status.HTTP_400_BAD_REQUEST
            )


class PutCliente(APIView):
    """
        Permite actualizar información de un cliente
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de cliente actualizado
                         http 400 => Retorna mensaje de error al actualizar cliente
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_cliente, format=None):
        try:
            cliente = Cliente.objects.get(id_cliente=id_cliente)
            clienteSerializer = ClienteSerializer(cliente, data=request.data)
            if clienteSerializer.is_valid():
                clienteSerializer.save()
                return Response(
                    {"message": "Se ha actualizado el cliente"},
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"message": "No actualizar el cliente con id " + id_cliente},
                status=status.HTTP_400_BAD_REQUEST
            )
