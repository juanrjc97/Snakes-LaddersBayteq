from django.db import models


class Cliente(models.Model):
    id_cliente = models.AutoField(primary_key=True, unique=True)
    nombre = models.CharField(max_length=100, verbose_name="Nombre")
    email = models.CharField(max_length=200, verbose_name="Email")
    pais = models.CharField(max_length=200, verbose_name="País")
    direccion = models.CharField(max_length=200, verbose_name="Dirección")
    activo = models.BooleanField(default=True)
    destino_orden = models.CharField(
        max_length=200, verbose_name="Destino Orden")
    notify_address = models.CharField(
        max_length=200, verbose_name="Notify Address")
    notify = models.CharField(max_length=200, verbose_name="Notify")
    telefono = models.CharField(max_length=13, verbose_name="Teléfono")

    class Meta:
        verbose_name = "Cliente"
        verbose_name_plural = "Clientes"

    def __str__(self):
        return '{}'.format(self.nombre)
