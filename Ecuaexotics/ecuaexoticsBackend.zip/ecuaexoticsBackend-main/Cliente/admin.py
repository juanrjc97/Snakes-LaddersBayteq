from django.contrib import admin
from .models import Cliente

myModels = [Cliente]
admin.site.register(myModels)
