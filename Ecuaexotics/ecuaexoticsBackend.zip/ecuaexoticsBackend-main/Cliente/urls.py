from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path("obtener_clientes/", GetListCliente.as_view()),
    path("obtener_clientes_todos/", GetAllListCliente.as_view()),
    path("guardar_cliente/", SaveCliente.as_view()),
    path("obtener_cliente_by_id/<str:id_cliente>/", GetClienteById.as_view()),
    path("actualizar_cliente_by_id/<str:id_cliente>/", PutCliente.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
