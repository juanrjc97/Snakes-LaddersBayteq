from .models import Productor
from rest_framework import serializers


class ProductorSerializer(serializers.ModelSerializer):

    class Meta:
        model = Productor
        fields = '__all__'
