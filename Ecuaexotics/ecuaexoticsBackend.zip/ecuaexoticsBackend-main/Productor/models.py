from django.db import models


class Productor(models.Model):
    id_productor = models.AutoField(primary_key=True, unique=True)
    nombre = models.CharField(max_length=100, verbose_name="Nombre")
    apellido = models.CharField(max_length=100, verbose_name="Apellido")
    email = models.CharField(max_length=200, verbose_name="Email")
    direccion = models.CharField(max_length=200, verbose_name="Dirección")
    telefono = models.CharField(max_length=10, verbose_name="Teléfono")
    activo = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Productor"
        verbose_name_plural = "Productores"

    def __str__(self):
        return '{} {}'.format(self.nombre, self.apellido)
