from .models import Productor
from .serializers import ProductorSerializer

from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView


class GetListProductor(APIView):
    """
        Permite obtener listado de productores activos
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna json con todos los productores
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        productorObject = Productor.objects.all().order_by(
            'nombre').filter(Q(activo=True))
        productorSerializer = ProductorSerializer(
            productorObject, many=True)
        return Response(productorSerializer.data, status=status.HTTP_200_OK)


class GetAllListProductor(APIView):
    """
        Permite obtener listado de productores, indpendiente de si esta activo o no
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna listado de productores
    """
    # permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        productorObject = Productor.objects.all().order_by(
            'nombre')
        productorSerializer = ProductorSerializer(
            productorObject, many=True)
        return Response(productorSerializer.data, status=status.HTTP_200_OK)


class SaveProductor(APIView):
    """
        Permite guardar un nuevo productor
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de productor registrado
                         http 400 => Retorna mensaje de error al guardar productor
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        try:
            productorSerializer = ProductorSerializer(data=request.data)
            if productorSerializer.is_valid():
                productorSerializer.save()
                return Response(
                    {"message": "Se ha guardo el productor correctamente"},
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"message": "No se ha podido crear el productor"},
                status=status.HTTP_400_BAD_REQUEST
            )


class GetProductorById(APIView):
    """
        Permite obtener información de productor a partir del id
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna json del productor solicitado
                         http 400 => Retorna mensaje de error al no encontrar productor en base al id
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_productor, format=None):
        try:
            productor = Productor.objects.get(id_productor=id_productor)
            productorSerializer = ProductorSerializer(productor)
            return Response(
                productorSerializer.data,
                status=status.HTTP_200_OK
            )
        except:
            return Response(
                {"message": "No existe productor con id " + id_productor},
                status=status.HTTP_400_BAD_REQUEST
            )


class PutProductor(APIView):
    """
        Permite actualizar información de un productor
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de productor actualizado
                         http 400 => Retorna mensaje de error al actualizar productor
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_productor, format=None):
        try:
            productor = Productor.objects.get(id_productor=id_productor)
            productorSerializer = ProductorSerializer(
                productor, data=request.data)
            if productorSerializer.is_valid():
                productorSerializer.save()
                return Response(
                    {"message": "Se ha actualizado el productor"},
                    status=status.HTTP_200_OK
                )
        except:
            return Response(
                {"message": "No actualizar el productor con id " + id_productor},
                status=status.HTTP_400_BAD_REQUEST
            )
