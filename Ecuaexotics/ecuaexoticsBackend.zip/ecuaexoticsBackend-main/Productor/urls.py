from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path("guardar_productor/", SaveProductor.as_view()),
    path("obtener_productores/", GetListProductor.as_view()),
    path("obtener_productores_todos/", GetAllListProductor.as_view()),
    path("obtener_productor_by_id/<str:id_productor>/",
         GetProductorById.as_view()),
    path("actualizar_productor_by_id/<str:id_productor>/", PutProductor.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
