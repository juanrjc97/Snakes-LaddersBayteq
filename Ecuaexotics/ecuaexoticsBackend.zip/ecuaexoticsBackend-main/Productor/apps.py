from django.apps import AppConfig


class ProductorConfig(AppConfig):
    name = 'Productor'
