from django.contrib import admin
from .models import Productor

myModels = [Productor]
admin.site.register(myModels)
