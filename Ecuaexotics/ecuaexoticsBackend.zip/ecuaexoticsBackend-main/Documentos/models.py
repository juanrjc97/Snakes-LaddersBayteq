from django.db import models
from Cliente.models import Cliente
from Palletizado.models import Palletizado


class PackingList(models.Model):
    id_packing = models.AutoField(primary_key=True, unique=True)
    factura_num = models.CharField(
        max_length=50, blank=True, null=True, verbose_name="Nº de Factura")
    linea_area = models.CharField(
        max_length=50, blank=True, null=True, verbose_name="Línea Área")
    awb = models.CharField(
        max_length=50, blank=True, null=True, verbose_name="AWB")
    fda_num = models.CharField(
        max_length=50, blank=True, null=True, verbose_name="Nº de FDA")
    packing_num = models.CharField(
        max_length=50, blank=True, null=True, verbose_name="Nº de Paking List")
    fecha = models.DateField(blank=True, null=True, verbose_name="Fecha")
    total_peso = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Total Peso")
    informacion_extra = models.TextField(
        blank=True, null=True, verbose_name="Información extra")
    estado = models.BooleanField(default=False, verbose_name="Estado")
    id_cliente = models.ForeignKey(
        Cliente, on_delete=models.PROTECT, verbose_name="Cliente")
    id_palletizado = models.ForeignKey(
        Palletizado, on_delete=models.CASCADE, verbose_name="Palletizado")

    class Meta:
        verbose_name = "Packing List"
        verbose_name_plural = "Packing List"

    def __str__(self):
        return '{}'.format(self.id_cliente.nombre)


class Factura(models.Model):
    id_factura = models.AutoField(primary_key=True, unique=True)
    fecha = models.DateField(blank=True, null=True, verbose_name="Fecha")
    referencia_exportacion = models.CharField(
        max_length=20, blank=True, null=True, verbose_name="Referencia de exportación")
    estado = models.BooleanField(default=False, verbose_name="Estado")
    factura_num = models.CharField(
        max_length=50, blank=True, null=True, verbose_name="Nº de Factura")
    subtotal = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Subtotal")
    impuesto = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Impuesto")
    total = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Total")
    id_cliente = models.ForeignKey(
        Cliente, on_delete=models.PROTECT, verbose_name="Cliente")
    id_palletizado = models.ForeignKey(
        Palletizado, on_delete=models.CASCADE, verbose_name="Palletizado")

    class Meta:
        verbose_name = "Factura"
        verbose_name_plural = "Facturas"

    def __str__(self):
        return '{}'.format(self.id_cliente.nombre)


class ItemFactura(models.Model):
    yellow = "Yellow Dragon Fruit"
    red = "Red Dragon Fruit"

    cb4 = "Carton Box 4.5 kg net weight"
    cb2 = "Carton Box 2.5 kg net weight"

    tipos_pitahaya = [
        (yellow, "Yellow Dragon Fruit"),
        (red, "Red Dragon Fruit"),
    ]

    tipos_caja = [
        (cb4, "Carton Box 4.5 kg net weight"),
        (cb2, "Carton Box 2.5 kg net weight"),
    ]

    id_item_factura = models.AutoField(primary_key=True, unique=True)
    tipo = models.CharField(
        choices=tipos_pitahaya, default=red, max_length=50, verbose_name="Tipo pitahaya")
    descripcion_producto = models.CharField(
        choices=tipos_caja, default=cb4, max_length=50, verbose_name="Tipo caja")
    cantidad = models.IntegerField(default=0, verbose_name="Cantidad")
    precio_caja = models.DecimalField(
        max_digits=60, decimal_places=2, default=0.00, verbose_name="Precio Caja")
    id_factura = models.ForeignKey(
        Factura, on_delete=models.CASCADE, verbose_name="Palletizado")

    class Meta:
        verbose_name = "Item Factura"
        verbose_name_plural = "Items Factura"

    def __str__(self):
        return '{} {} {}'.format(self.id_item_factura, self.tipo, self.descripcion_producto)
