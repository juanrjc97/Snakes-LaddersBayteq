from Palletizado.models import ItemPallet, Pallet
from .models import PackingList, Factura, ItemFactura
from .serializers import ItemFacturaSimpleSerializer
from Bodega.models import Bodega
from django.db.models import Q
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView
from .initialState import statePackingList, stateFactura, stateSimpleFactura


class GetListPackingByIdCliente(APIView):
    """
        Permite listado de packing list asociados a clientes
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna listado de json con packing list
                         http 400 => Retorna mensaje de error al no existir cliente con id solicitado
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_cliente, format=None):
        try:
            yellow = "Yellow Dragon Fruit"
            red = "Red Dragon Fruit"
            cb4 = "Carton Box 4.5 kg net weight"
            cb2 = "Carton Box 2.5 kg net weight"
            packingList = PackingList.objects.filter(
                Q(id_cliente=id_cliente)).order_by('-id_packing')
            data = []
            if len(packingList) > 0:
                for pkg in packingList:
                    sumPesoNeto = 0
                    cantidadTotal = 0
                    packingObject = statePackingList(
                        pkg, yellow, red, cb2, cb4)

                    palletList = Pallet.objects.filter(
                        Q(id_palletizado=pkg.id_palletizado.id_palletizado) &
                        Q(id_cliente=id_cliente)
                    )

                    for palletOb in palletList:
                        tipo_pitahaya = palletOb.tipo_pitahaya
                        itemsPalletList = ItemPallet.objects.filter(
                            Q(id_pallet=palletOb.id_pallet)
                        )

                        for itemObj in itemsPalletList:
                            calibresOfDict = packingObject["items_tipo_pitahaya"][
                                tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres']
                            if itemObj.calibre in calibresOfDict.keys():
                                calibreObjeto = packingObject["items_tipo_pitahaya"][
                                    tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres'][itemObj.calibre]

                                packingObject["items_tipo_pitahaya"][
                                    tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres'][itemObj.calibre] = calibreObjeto['cantidad'] + itemObj.num_cajas
                            else:
                                packingObject["items_tipo_pitahaya"][
                                    tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres'][itemObj.calibre] = itemObj.num_cajas

                    listTipoPitahaya = []
                    for c, itemsTipoPita in packingObject["items_tipo_pitahaya"].items():
                        listByCajaPitahaya = []
                        cantidadByPitahaya = 0
                        pesoNetoByPitahaya = 0
                        for cajaTipo in itemsTipoPita["items_tipo_caja"].values():
                            calibres = cajaTipo["calibres"]
                            if len(calibres) > 0:
                                newCalibre = [{"calibre": ca, "num_cajas": v, "tipo_pitahaya": itemsTipoPita["tipo_pitahaya"]}
                                              for ca, v in calibres.items()]
                                for cant in calibres.values():
                                    cantidadTotal += cant
                                    cantidadByPitahaya += cant
                                    if '2.5' in cajaTipo["tipo_caja"]:
                                        sumPesoNeto += cant * 2.5
                                        pesoNetoByPitahaya += cant * 2.5
                                    if '4.5' in cajaTipo["tipo_caja"]:
                                        sumPesoNeto += cant * 4.5
                                        pesoNetoByPitahaya += cant * 4.5
                                listByCajaPitahaya.append(
                                    {
                                        "tipo_caja": cajaTipo["tipo_caja"],
                                        "calibres":
                                            newCalibre
                                    }
                                )
                        listTipoPitahaya.append(
                            {
                                "tipo_pitahaya": c,
                                "cantidad_tipo": cantidadByPitahaya,
                                "pesoNetoByPitahaya": pesoNetoByPitahaya,
                                "items_tipo_caja": listByCajaPitahaya
                            }
                        )
                    packingObject["packing"]["total_peso"] = round(
                        sumPesoNeto, 2)
                    packingObject["packing"]["cantidad"] = cantidadTotal
                    data.append(
                        {
                            "packing": packingObject["packing"],
                            "items_tipo_pitahaya": listTipoPitahaya
                        }
                    )

            return Response(data, status=status.HTTP_200_OK)
        except:
            return Response({"message": "Error"}, status=status.HTTP_400_BAD_REQUEST)


class GetFacturaByIdCliente(APIView):
    """
        Permite obtener listado de facturas de clientes a partir del id
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna listado json de facturas de clientes
                         http 400 => Retorna mensaje de error al no existir clientes con id solicitado
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def get(self, request, id_cliente, format=None):
        try:
            yellow = "Yellow Dragon Fruit"
            red = "Red Dragon Fruit"
            cb4 = "Carton Box 4.5 kg net weight"
            cb2 = "Carton Box 2.5 kg net weight"
            facturaList = Factura.objects.filter(
                Q(id_cliente=id_cliente)).order_by('-id_factura')
            data = []
            if len(facturaList) > 0:
                for invoice in facturaList:
                    itemFacturaList = ItemFactura.objects.filter(
                        Q(id_factura=invoice.id_factura)
                    )

                    if len(itemFacturaList) == 0:
                        facturaObject = stateSimpleFactura(
                            invoice, yellow, red, cb2, cb4)
                        palletList = Pallet.objects.filter(
                            Q(id_palletizado=invoice.id_palletizado.id_palletizado) &
                            Q(id_cliente=id_cliente)
                        )

                        for palletOb in palletList:
                            tipo_pitahaya = palletOb.tipo_pitahaya
                            itemsPalletList = ItemPallet.objects.filter(
                                Q(id_pallet=palletOb.id_pallet)
                            )

                            for itemObj in itemsPalletList:
                                calibresOfDict = facturaObject["items_tipo_pitahaya"][
                                    tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres']
                                if itemObj.calibre in calibresOfDict.keys():
                                    calibreObjeto = facturaObject["items_tipo_pitahaya"][
                                        tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres'][itemObj.calibre]

                                    facturaObject["items_tipo_pitahaya"][
                                        tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres'][itemObj.calibre] = calibreObjeto['cantidad'] + itemObj.num_cajas
                                else:
                                    facturaObject["items_tipo_pitahaya"][
                                        tipo_pitahaya]['items_tipo_caja'][itemObj.tipo_caja]['calibres'][itemObj.calibre] = itemObj.num_cajas

                        listTipoPitahaya = []
                        for c, itemsTipoPita in facturaObject["items_tipo_pitahaya"].items():
                            listByCajaPitahaya = []
                            for cajaTipo in itemsTipoPita["items_tipo_caja"].values():
                                calibres = cajaTipo["calibres"]
                                if len(calibres) > 0:
                                    sumCant = 0
                                    for cant in calibres.values():
                                        sumCant += cant
                                    try:
                                        dataItemFact = {
                                            "tipo": itemsTipoPita["tipo_pitahaya"],
                                            "descripcion_producto": cajaTipo["tipo_caja"],
                                            "cantidad": sumCant,
                                            "precio_caja": 0.0,
                                            "id_factura": facturaObject["factura"]["id_factura"]
                                        }
                                        itemFactSerializer = ItemFacturaSimpleSerializer(
                                            data=dataItemFact)
                                        if itemFactSerializer.is_valid():
                                            itemFactSerializer.save()
                                    except:
                                        pass

                    facturaObject = stateFactura(
                        invoice, yellow, red, cb2, cb4)
                    itemFacturaList = ItemFactura.objects.filter(
                        Q(id_factura=invoice.id_factura)
                    )
                    for itemFact in itemFacturaList:
                        facturaObject["items_tipo_pitahaya"][itemFact.tipo]["items_tipo_caja"][itemFact.descripcion_producto] = {
                            "id_item_factura": itemFact.id_item_factura,
                            "tipo": itemFact.tipo,
                            "descripcion_producto": itemFact.descripcion_producto,
                            "cantidad": itemFact.cantidad,
                            "precio_caja": itemFact.precio_caja
                        }
                    listTipoPitahaya = []
                    for c, itemsTipoPita in facturaObject["items_tipo_pitahaya"].items():
                        listByCajaPitahaya = []
                        for cajaTipo in itemsTipoPita["items_tipo_caja"].values():
                            listByCajaPitahaya.append(
                                cajaTipo
                            )
                        listTipoPitahaya.append(
                            {
                                "tipo_pitahaya": c,
                                "items_tipo_caja": listByCajaPitahaya
                            }
                        )
                    data.append(
                        {
                            "factura": facturaObject["factura"],
                            "items_tipo_pitahaya": listTipoPitahaya
                        }
                    )

            return Response(data, status=status.HTTP_200_OK)
        except:
            return Response({"message": "Error"}, status=status.HTTP_400_BAD_REQUEST)


class UpdateItemFactura(APIView):
    """
        Permite actualizar un item de factura, especificamente el precio al que se le vende a un cliente
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de actualización realziada con éxito
                         http 400 => Retorna mensaje de error al actualizar item
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_item_factura, format=None):
        try:
            precio = round(request.data['precio_caja'], 2)
            itemObject = ItemFactura.objects.get(
                id_item_factura=id_item_factura)
            if itemObject:
                itemObject.precio_caja = precio
                itemObject.save()

                itemsFactList = ItemFactura.objects.filter(
                    Q(id_factura=itemObject.id_factura.id_factura)
                )
                subtotalSum = 0
                for itemFact in itemsFactList:
                    subtotalSum += itemFact.cantidad * \
                        float(itemFact.precio_caja)

                facturaObject = Factura.objects.get(
                    id_factura=itemObject.id_factura.id_factura)
                if facturaObject:
                    facturaObject.subtotal = round(subtotalSum, 2)
                    impCal = (subtotalSum *
                              float(facturaObject.impuesto)) / 100
                    total = subtotalSum - impCal
                    facturaObject.total = round(total, 2)
                    facturaObject.save()

            return Response(
                {
                    "message": "Actualizado Item"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido crear actualizar el precio del item"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class UpdateInfoFactura(APIView):
    """
        Permite actualizar la inforamción de una factura a un cliente, campos como id de fectura, fecha
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de actualización correcta
                         http 400 => Retorna mensaje de error al actualizar factura
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_factura, format=None):
        try:
            facturaObject = Factura.objects.get(id_factura=id_factura)
            if facturaObject:
                facturaObject.fecha = request.data['fecha']
                facturaObject.referencia_exportacion = request.data['referencia_exportacion']
                facturaObject.factura_num = request.data['factura_num']
                facturaObject.save()
            return Response(
                {
                    "message": "Información de factura actualizada"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido crear actualizar información de factura"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class UpdateEstadoFactura(APIView):
    """
        Permite cambiar el estado de factura a finalizado
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de factura finalziada
                         http 400 => Retorna mensaje de error al actualziar estado de factura
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_factura, format=None):
        try:
            facturaObject = Factura.objects.get(id_factura=id_factura)
            if facturaObject:
                facturaObject.estado = request.data['estado']
                facturaObject.save()
            return Response(
                {
                    "message": "Factura finalizada"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido finalizar la factura"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )


class UpdateInfoPackingList(APIView):
    """
        Permite actualizar inforamción del packing list, como numero de factura, linea aerea, fda, etc
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna mensaje de actualizada la información
                         http 400 => Retorna mensaje de error al actualizar
    """

    # La siguiente linea permite validacion de acceso a la información por token
    # permission_classes = [IsAuthenticated]

    def put(self, request, id_packing, format=None):
        try:
            packingObject = PackingList.objects.get(id_packing=id_packing)
            if packingObject:
                packingObject.factura_num = request.data['factura_num']
                packingObject.linea_area = request.data['linea_area']
                packingObject.awb = request.data['awb']
                packingObject.fda_num = request.data['fda_num']
                packingObject.packing_num = request.data['packing_num']
                packingObject.fecha = request.data['fecha']
                packingObject.informacion_extra = request.data['informacion_extra']
                packingObject.estado = True
                packingObject.save()
            return Response(
                {
                    "message": "Información de PackingList actualizada"
                },
                status=status.HTTP_200_OK,
            )
        except:
            return Response(
                {
                    "message": "No se ha podido crear actualizar información del PackingList"
                },
                status=status.HTTP_400_BAD_REQUEST,
            )
