from django.apps import AppConfig


class DocumentosConfig(AppConfig):
    name = 'Documentos'
