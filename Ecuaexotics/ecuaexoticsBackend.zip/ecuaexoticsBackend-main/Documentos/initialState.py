
def statePackingList(pkg, yellow, red, cb2, cb4):
    return {
        "packing": {
            "id_packing": pkg.id_packing,
            "factura_num": pkg.factura_num,
            "linea_area": pkg.linea_area,
            "awb": pkg.awb,
            "fda_num": pkg.fda_num,
            "packing_num": pkg.packing_num,
            "fecha": pkg.fecha,
            "total_peso": pkg.total_peso,
            "cantidad": 0,
            "informacion_extra": pkg.informacion_extra,
            "estado": pkg.estado
        },
        "items_tipo_pitahaya": {
            yellow: {
                "tipo_pitahaya": yellow,
                "items_tipo_caja": {
                    cb2: {
                        "tipo_caja": cb2,
                        "calibres": {}
                    },
                    cb4: {
                        "tipo_caja": cb4,
                        "calibres": {}
                    }
                }
            },
            red: {
                "tipo_pitahaya": red,
                "cantidad_tipo": 0,
                "items_tipo_caja": {
                    cb2: {
                        "tipo_caja": cb2,
                        "calibres": {}
                    },
                    cb4: {
                        "tipo_caja": cb4,
                        "calibres": {}
                    }
                }
            }
        }
    }


def stateFactura(invoice, yellow, red, cb2, cb4):
    return {
        "factura": {
            "id_factura": invoice.id_factura,
            "fecha": invoice.fecha,
            "referencia_exportacion": invoice.referencia_exportacion,
            "factura_num": invoice.factura_num,
            "estado": invoice.estado,
            "subtotal": invoice.subtotal,
            "impuesto": invoice.impuesto,
            "total": invoice.total,
            "id_cliente": invoice.id_cliente.id_cliente,
            "id_palletizado": invoice.id_palletizado.id_palletizado
        },
        "items_tipo_pitahaya": {
            yellow: {
                "tipo_pitahaya": yellow,
                "items_tipo_caja": {
                    cb2: {
                        "id_item_factura": 0,
                        "tipo": yellow,
                        "descripcion_producto": cb2,
                        "cantidad": 0,
                        "precio_caja": 0.0
                    },
                    cb4: {
                        "id_item_factura": 0,
                        "tipo": yellow,
                        "descripcion_producto": cb4,
                        "cantidad": 0,
                        "precio_caja": 0.0
                    }
                }
            },
            red: {
                "tipo_pitahaya": red,
                "items_tipo_caja": {
                    cb2: {
                        "id_item_factura": 0,
                        "tipo": red,
                        "descripcion_producto": cb2,
                        "cantidad": 0,
                        "precio_caja": 0.0
                    },
                    cb4: {
                        "id_item_factura": 0,
                        "tipo": red,
                        "descripcion_producto": cb4,
                        "cantidad": 0,
                        "precio_caja": 0.0
                    }
                }
            }
        }
    }


def stateSimpleFactura(invoice, yellow, red, cb2, cb4):
    return {
        "factura": {
            "id_factura": invoice.id_factura,
            "fecha": invoice.fecha,
            "referencia_exportacion": invoice.referencia_exportacion,
            "factura_num": invoice.factura_num,
            "estado": invoice.estado,
            "subtotal": invoice.subtotal,
            "impuesto": invoice.impuesto,
            "total": invoice.total,
            "id_cliente": invoice.id_cliente.id_cliente,
            "id_palletizado": invoice.id_palletizado.id_palletizado
        },
        "items_tipo_pitahaya": {
            yellow: {
                "tipo_pitahaya": yellow,
                "items_tipo_caja": {
                    cb2: {
                        "tipo_caja": cb2,
                        "cantidad": 0,
                        "calibres": {}
                    },
                    cb4: {
                        "tipo_caja": cb4,
                        "cantidad": 0,
                        "calibres": {}
                    }
                }
            },
            red: {
                "tipo_pitahaya": red,
                "items_tipo_caja": {
                    cb2: {
                        "tipo_caja": cb2,
                        "cantidad": 0,
                        "calibres": {}
                    },
                    cb4: {
                        "tipo_caja": cb4,
                        "cantidad": 0,
                        "calibres": {}
                    }
                }
            }
        }
    }
