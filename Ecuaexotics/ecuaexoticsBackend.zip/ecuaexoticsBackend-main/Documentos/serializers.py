from .models import PackingList, Factura, ItemFactura
from rest_framework import serializers


class PackingListSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = PackingList
        fields = [
            'id_cliente',
            'id_palletizado'
        ]


class FacturaSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = Factura
        fields = [
            'id_cliente',
            'id_palletizado'
        ]


class ItemFacturaSimpleSerializer(serializers.ModelSerializer):

    class Meta:
        model = ItemFactura
        fields = [
            'tipo',
            'descripcion_producto',
            'cantidad',
            'precio_caja',
            'id_factura'
        ]
