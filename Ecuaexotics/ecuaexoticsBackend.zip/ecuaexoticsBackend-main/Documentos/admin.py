from django.contrib import admin
from .models import PackingList, Factura, ItemFactura

myModels = [PackingList, Factura, ItemFactura]
admin.site.register(myModels)
