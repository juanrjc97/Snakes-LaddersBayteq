from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path("obtener_packinglist_cliente/<str:id_cliente>/",
         GetListPackingByIdCliente.as_view()),
    path("obtener_facturas_cliente/<str:id_cliente>/",
         GetFacturaByIdCliente.as_view()),

    path("actualizar_item_factura/<str:id_item_factura>/",
         UpdateItemFactura.as_view()),
    path("actualizar_info_factura/<str:id_factura>/",
         UpdateInfoFactura.as_view()),
    path("actualizar_estado_factura/<str:id_factura>/",
         UpdateEstadoFactura.as_view()),

    path("actualizar_info_packinglist/<str:id_packing>/",
         UpdateInfoPackingList.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
