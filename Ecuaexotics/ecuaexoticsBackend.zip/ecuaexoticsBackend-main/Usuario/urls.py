
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from .views import *

urlpatterns = [
    path('users/', user_api_view),
    path('users-detalle/<str:id>/', user_detail_view),
    path('login/', LoginApiView.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)
