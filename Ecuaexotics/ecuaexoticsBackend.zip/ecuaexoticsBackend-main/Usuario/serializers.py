from rest_framework import serializers
from .models import Usuario
from django.contrib import auth
from rest_framework.exceptions import AuthenticationFailed


class UsuarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = [
            'email', 'nombre', 'apellido', 'username', 'is_active', 'rol', 'id'
        ]


class UsuarioUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Usuario
        fields = [
            'email',
            'nombre',
            'apellido',
            'username',
            'is_active',
            'rol',
            'is_active'
        ]


class RegisterUsuarioSerializer(serializers.ModelSerializer):
    email = serializers.CharField(
        max_length=250, min_length=10, write_only=True)
    password = serializers.CharField(
        max_length=200, min_length=2, write_only=True)
    username = serializers.CharField(max_length=100, write_only=True)
    nombre = serializers.CharField(max_length=80, write_only=True)
    apellido = serializers.CharField(max_length=80, write_only=True)
    rol = serializers.CharField(max_length=30, write_only=True)
    is_active = serializers.BooleanField(write_only=True)

    class Meta:
        model = Usuario
        fields = [
            'email',
            'nombre',
            'apellido',
            'password',
            'username',
            'is_active',
            'rol'
        ]

    def validate(self, attrs):
        email = attrs.get('email', '')
        if len(Usuario.objects.filter(email=email)) > 0:
            raise serializers.ValidationError(
                'Email ya está registrado'
            )
        return attrs

    def create(self, validated_data):
        password = validated_data.get('password')
        validated_data['password'] = password
        return Usuario.objects.create_user(**validated_data)


class LoginSerializer(serializers.ModelSerializer):
    email = serializers.CharField(
        max_length=250, min_length=10, write_only=True)
    password = serializers.CharField(
        max_length=200, min_length=2, write_only=True)
    information = serializers.JSONField(read_only=True)
    tokens = serializers.JSONField(read_only=True)

    class Meta:
        model = Usuario
        fields = ['email', 'password', 'information', 'tokens']

    def validate(self, attrs):
        email = attrs.get("email", '')
        # Se obtiene la constraseña
        password = attrs.get("password", '')

        # Se Realiza valdiaciones de contraseña, cuenta deshabilitada
        if password is None:
            raise AuthenticationFailed('Contraseña Inválida')

        usuarioObj = Usuario.objects.filter(email=email)
        if len(usuarioObj) > 0:
            validateActiveUser = Usuario.objects.get(email=email)
            if not validateActiveUser.is_active:
                raise AuthenticationFailed('Cuenta inactiva')

            user = auth.authenticate(email=email, password=password)
            if not user:
                raise AuthenticationFailed('Credenciales Inválidas')

            return {
                'information': user.information(),
                'tokens': user.tokens()
            }
        else:
            raise AuthenticationFailed('Credenciales Inválidas')

        # return super().validate(attrs)
