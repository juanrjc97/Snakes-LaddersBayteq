from django.db import models
from django.utils.translation import gettext_lazy as _
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from rest_framework_simplejwt.tokens import RefreshToken


class UserManager(BaseUserManager):
    def create_user(self, email, username, nombre, apellido, password, **other_fields):
        if not email:
            raise ValueError(_('Es necesario una dirección de correo'))

        email = self.normalize_email(email)
        user = self.model(email=email, username=username,
                          nombre=nombre, apellido=apellido, **other_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, username, nombre, apellido, password, **other_fields):
        other_fields.setdefault('is_staff', True)
        other_fields.setdefault('is_superuser', True)
        other_fields.setdefault('is_active', True)

        if other_fields.get('is_staff') is not True:
            raise ValueError('Superuser debe ser asigando si is_staff = True')
        if other_fields.get('is_superuser') is not True:
            raise ValueError(
                'Superuser debe ser asignado con is_superuser = True')
        return self.create_user(email, username, nombre, apellido, password, **other_fields)


class Usuario(AbstractBaseUser, PermissionsMixin):
    superadmin = "Superadmin"
    admin = "Admin"
    operador1 = "Operador_bodega"
    operador2 = "Operador_calibrado"
    operador3 = "Operador_palletizado"

    roles = [
        (superadmin, "Superadmin"),
        (admin, "Admin"),
        (operador1, "Operador_bodega"),
        (operador2, "Operador_calibrado"),
        (operador3, "Operador_palletizado"),
    ]

    id = models.AutoField(primary_key=True, unique=True)
    email = models.EmailField(_('email address'), max_length=200, unique=True)
    password = models.CharField(max_length=100)
    username = models.CharField(
        max_length=100, unique=True, verbose_name="Username")
    nombre = models.CharField(max_length=80, verbose_name="Nombre")
    apellido = models.CharField(max_length=80, verbose_name="Apellido")
    rol = models.CharField(max_length=30, choices=roles,
                           default=admin, verbose_name="Rol")
    created = models.DateTimeField(
        auto_now_add=True, help_text="Fecha de creación")
    updated = models.DateTimeField(
        auto_now_add=True, help_text="Fecha de modificación")

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = 'email'

    REQUIRED_FIELDS = ['password', 'username', 'nombre', 'apellido']

    def __str__(self):
        return "{}".format(self.nombre + " " + self.apellido)

    def information(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'apellido': self.apellido,
            'username': self.username,
            'email': self.email,
            'rol': self.rol,
        }

    def tokens(self):
        refresh = RefreshToken.for_user(self)
        return {
            'refresh': str(refresh),
            'access': str(refresh.access_token)
        }
