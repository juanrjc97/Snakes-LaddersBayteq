from django.contrib import admin
from .models import Usuario
from django.contrib.auth.admin import UserAdmin
# from django.forms import TextInput, Textarea


class UserAdminConfig(UserAdmin):
    model = Usuario
    search_fields = ('email', 'nombre', 'apellido', 'rol')
    list_filter = ('is_active', 'is_staff', 'rol')
    # ordering = ('-start_date',)
    list_display = ('email', 'nombre', 'apellido',
                    'is_active', 'is_staff', 'is_superuser', 'rol')
    fieldsets = (
        ('Información', {'fields': ('email', 'username',
         'nombre', 'apellido', 'password', 'rol')}),
        ('Permisos', {'fields': ('is_staff', 'is_active', 'is_superuser')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'nombre', 'apellido', 'password1', 'password2', 'is_active', 'is_staff', 'is_superuser', 'rol')}
         ),
    )


# myModels = [ User, UserAdminConfig ]
admin.site.register(Usuario, UserAdminConfig)
