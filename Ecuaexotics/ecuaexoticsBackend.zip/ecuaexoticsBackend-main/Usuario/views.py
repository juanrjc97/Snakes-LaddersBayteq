from rest_framework.views import APIView
from django.db.models import Q
from rest_framework.response import Response
from .models import Usuario
from .serializers import UsuarioSerializer, UsuarioUpdateSerializer, LoginSerializer, RegisterUsuarioSerializer
from rest_framework import status
from django.http import Http404
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

# from Clientes.models import UserCliente, Customer

# KEY_Crypto_PASSWORD = '$ky5ctn0$1-2021!'


class LoginApiView(APIView):
    """
        Permite realizar la autenticacion de usuario 
    Args:
        APIView (views): Para indicar que es una view para API REST
    Returns:
        Response: Status http 200 => Retorna conjunto de datos como token, nombre, apellidos, email, etc
                                     del usaurio que se autentico correctamente
                                     Caso contrario envia error de autenticacion por
                                     ** credenciales invalidas
                                     ** contraseña invalida
                                     ** usuario o cuenta inactiva
    """

    def post(self, request, format=None):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response({"data": serializer.data}, status=status.HTTP_200_OK)


@api_view(["GET", "POST"])
# @permission_classes([IsAuthenticated])
def user_api_view(request):
    """ 
        METHOD GET
        Permite obtener todos los usuarios que se encuentra guardados en el modelo User
    Returns:
        Response: Retorna lista de usuarios y status http 200
    """

    """
        METHOD POST 
       Permite crear un objeto con informacion de usuario en el modelo User
    
    Args:
        request (http): Solicitud Http que llega desde el frontend
                        request.data contiene los datos del usuario a guardar
    Returns:
        Response: Status http 201 => Retorna mensaje de usuario creado
                  Status http 400 => Error al guardar el usuario en modelo User
    """
    if request.method == "GET":
        users = Usuario.objects.filter(
            Q(is_superuser=False)).order_by('nombre')
        usersdata = UsuarioSerializer(users, many=True)
        return Response(usersdata.data, status=status.HTTP_200_OK)

    elif request.method == "POST":

        try:
            userSerializer = RegisterUsuarioSerializer(data=request.data)
            userSerializer.is_valid(raise_exception=True)
            userSerializer.save()

            return Response(
                {"message": "Usuario creado correctamente"},
                status=status.HTTP_201_CREATED,
            )
        except:
            return Response(
                {"message": "Usuario no creado "},
                status=status.HTTP_400_BAD_REQUEST,
            )


@api_view(["GET", "PUT", "DELETE"])
# @permission_classes([IsAuthenticated])
def user_detail_view(request, id=None):
    """
        Permite Actualizar, eliminar u obtener un usuario del modelo User a partir del id
    Args:
        request (http): Identifica que tipo de solicitud es: GET, PUT, DELETE
        id (str, optional): Contiene el id del usuario. Defaults to None.
    Returns:
        Response: 
                Method GET
                  Status http 200 => Retorna el usuario solicitado
                  Status http 400 => Error al obtener el usuario,es posible que el usuario
                                     con id solicitado no existe
                Method PUT
                  Status http 202 => Retorna el mensaje de usuario actualizado
                  Status http 400 => Error al obtener al actualizar el usuario
                Method DELETE
                  Status http 200 => Retorna el mensaje de que se deshabilito el usuario solicitado
                  Status http 400 => No existe el usuario con el id a deshabilitar
    """
    try:
        user = Usuario.objects.get(id=id)
        if user:

            if request.method == "GET":
                userdata = UsuarioSerializer(user)
                return Response(userdata.data)

            # Update
            elif request.method == "PUT":
                if not user or (str(user.id) == str(id)):
                    userdata = UsuarioUpdateSerializer(
                        user, data=request.data)

                    if userdata.is_valid():
                        userdata.save()
                        # en caso de que la contraseña venga en los datos del request se procede a actualizar
                        if 'password' in request.data:
                            user.set_password(request.data['password'])
                            user.save()

                        return Response(
                            {"message": "Datos del usuario " + user.nombre +
                                " " + user.apellido + " actualizados"},
                            status=status.HTTP_202_ACCEPTED,
                        )
                    return Response(
                        {"message": "No se ha podido actualizar el usuario"},
                        status=status.HTTP_400_BAD_REQUEST,
                    )

                else:
                    return Response(
                        {"message": "Ya existe un usuario con el mismo email"},
                        status=status.HTTP_400_BAD_REQUEST,
                    )

            # Delete
            elif request.method == "DELETE":
                # en este caso no se elimina el objeto usaurio, solo se cambia el estado a inactivo
                user.is_active = False
                user.save()
                return Response(
                    {"message": "Usuario deshabilitado correctamente"},
                    status=status.HTTP_200_OK,
                )
    except:
        return Response(
            {"message": "No se ha encontrado al usuario"}, status=status.HTTP_400_BAD_REQUEST
        )
